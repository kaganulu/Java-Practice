/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generics1;

import java.util.ArrayList;

/**
 *
 * @author kaganulu
 */
public class Kuyruk<T> {

    private final ArrayList<T> elements;

    public Kuyruk() {
        this(10);
    }

    public Kuyruk(int x) {
        if (x <= 0) {
            x = 10;
        }
        elements = new ArrayList<T>(x);
    }

    public void add(T deger) {
        elements.add(deger);
    }

    public T pop() {
        if (elements.isEmpty()) {
            System.out.println("Yığın Boş!!");
            return null;
        }
        return elements.remove(0);
    }
}
