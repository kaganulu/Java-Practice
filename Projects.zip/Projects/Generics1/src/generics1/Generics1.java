/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generics1;

/**
 *
 * @author kaganulu
 */
public class Generics1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // Kuyruk<String> st = new Kuyruk(3);  // Kuyruk ta tshirt ilk görünür ama stack de son eklediğimiz çorap 
        Stack<String> st = new Stack(3);
        st.add("TShirt");
        st.add("Pantolon");
        st.add("Çorap");
        System.out.println(st.pop()); //çorap çıktı
        
        st.add("Kırmızı Çorap");//kırmızı çorap
        System.out.println(st.pop()); //kırmızı çorap çıktı
       
    }
    
}
