/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package methodebobekok;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class MethodEbobEkok {

    /**
     * @param args the command line arguments
     * 
     * 
     */
    
     private static int Ebob(int sayi1,int sayi2){
       int ebob =1;// Çünkü tüm sayılar 1 e tam bölünebilir. Ebob en az 1 olabilir.
       
       for(int i = 2;i<=sayi1&&i<=sayi2;i++){
           if(sayi1%i==0 && sayi2%i==0){
               ebob=i;
           } 
        }
       return ebob;
      
    }
 
    private static int Ekok(int sayi1,int sayi2,int ebob){
       int ekok = (sayi1*sayi2)/ebob;
       return ekok;
    }
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("1.Sayıyı giriniz:");
        int sayi1 = scan.nextInt();
        
        System.out.println("2.Sayıyı giriniz:");
        int sayi2 = scan.nextInt();
        
        int Ebob = Ebob(sayi1,sayi2);
        int Ekok = Ekok(sayi1,sayi2,Ebob);
        
        
        System.out.println("Girdiğiniz Sayıların \n"
                + "En Büyük Ortak Böleni (EBOB):  "+Ebob
                + "\nEn Küçük Ortak Katı (EKOK): "+Ekok+"'dir");
        
        
       
        
    }
    
}

