/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diziler;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Diziler {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        // a) 0 ile 999 arasinda 10tane rastgele tamsayiyi tutan diziyi yaratiniz.
        // b)sayıların 100 dahil ve 1000 dahil sayıların arasında olmak koşulunu sağlayın.
        Random rastgeleSayiOlusturucu = new Random();

        //a 
        /* int elemanSayisi =10;
         int[] sayilar = new int[elemanSayisi];
        
         for (int i = 0; i < sayilar.length; i++){
             sayilar[i] = rastgeleSayiOluşturucu.nextInt(1000);
             
         }
          for (int i = 0; i < sayilar.length; i++) {
                System.out.println(sayilar[i]+ " ");
               
                    
             }
         */
 /* int elemanSayisi =10;
       int[] sayilar = new int[elemanSayisi];
       int olusanSayi;
       
       for (int i = 0; i < sayilar.length; i++) {
            olusanSayi = rastgeleSayiOluşturucu.nextInt(1001);
            if(olusanSayi > 100) {
                sayilar[i] = olusanSayi;
            } else{
                i--;
            }
            
           }
         
            //System.out.println(sayilar);
            //System.out.println(sayilar.toString());
            
            for (int i = 0; i < sayilar.length; i++) {
                System.out.println(sayilar[i]+ " ");
               
                    
            }
         */
 /*
               Scanner scan = new Scanner(System.in);
               System.out.println("Kaç tane rakam tutulacak? ");
               int rakamSayisi = scan.nextInt();
               
               int[] girilenSayilar = new int [rakamSayisi];
               for (int i = 0; i < rakamSayisi; i++) {
                System.out.printf("Sayi %d yi giriniz: ", (i+1)); // %d tamsayılar için, %s yazılar için , %f ise ondalıklı sayılar için
                girilenSayilar[i] = scan.nextInt();;
             }
              
               for (int i = 0; i < girilenSayilar.length; i++) {
               System.out.println(girilenSayilar[i] + " ");
        }
      
         */
        // Dizilerle 10 elemanlı Fibonacci dizisi
        // 1 1 2 3 5 8 13 21..
        /*     
               int fib[] = new int[10];
               fib[0] = 1;
               fib[1] = 1;
               
               for (int i = 0; i < 8; i++) {
               fib[i+2] = fib[i+1] + fib[i]; 
        }
               /*for (int i = 2; i < 10; i++) {
               fib[i] = fib[i-1] + fib[i-2];
       } 
       
              for (int i = 0; i < 10; i++) {
               System.out.println(fib[i]);
        }
         */
        // Random sinifi ile 0-9 (dahil) 100 tane tam sayi oluşturun. 
        // Her bir sayidan kac tane oldugunu ekrana yazdırın.
        // Aynı sayiları tekrar yazdırmayacak.
        
        
         /*  int sayiAdedi= 100;
        int bulunanSayiAdedi=0;
        int[] sayilar = new int[sayiAdedi];
        int[] karsilastirilanSayilar = new int[10];
        int karsilastirilanSayiAdedi = 0;
        boolean oncedenKontrolEdildi = false;
        for (int i = 0; i < karsilastirilanSayilar.length; i++) {
            karsilastirilanSayilar[i]=Integer.MIN_VALUE;
        }
        
        for (int i = 0; i < sayiAdedi; i++) {
            sayilar[i] = rastgeleSayiOlusturucu.nextInt(10);
        }
        
        for (int i = 0; i < sayilar.length; i++) {
            bulunanSayiAdedi=0;
            oncedenKontrolEdildi = false;
            for (int j = 0; j < karsilastirilanSayilar.length; j++) {
                if (sayilar[i] == karsilastirilanSayilar[j]) {
                    oncedenKontrolEdildi = true;
                    break;
                }
            }
            if (oncedenKontrolEdildi) {
                continue;
            }
            for (int j = 0; j < sayilar.length; j++) {
                if(sayilar[i] == sayilar[j]) {
                    bulunanSayiAdedi++;
                }
            }
            if (bulunanSayiAdedi > 0) {
                System.out.println(sayilar[i]+"den " + bulunanSayiAdedi+"tane bulunmaktadır.");
            }
            karsilastirilanSayilar[karsilastirilanSayiAdedi] = sayilar[i];
            karsilastirilanSayiAdedi++;
        }
         */
        
        
        /*for (int i = 0; i < sayilar.length; i++) {
            bulunanSayiAdedi = 0;
            for (int j = 0; j < sayilar.length; j++) {
                if(sayilar[i] == sayilar[j]) {
                    bulunanSayiAdedi++;
                }
            }
            System.out.printf("Dizide %d sayisindan %d adet bulunmaktadir.\n", sayilar[i], bulunanSayiAdedi);
        }*/
        
        // 2. Çözüm 
        
        Random r = new Random(0);
        int[] sayilar = new int[100];
        for (int i = 0; i < sayilar.length; i++) {
            sayilar[i] = r.nextInt(10);
        }
        int[] adetliSayilar = new int[10];
        for (int i = 0; i < sayilar.length; i++) {
            adetliSayilar[sayilar[i]] = adetliSayilar[sayilar[i]]+1;
        }
        for (int i = 0; i < adetliSayilar.length; i++) {
            System.out.printf("%d sayisindan %d adet vardir.\n", i, adetliSayilar[i] );
        }
        
        
    }
    
}

   