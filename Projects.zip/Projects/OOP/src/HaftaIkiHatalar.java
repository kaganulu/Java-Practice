/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kaganulu
 */
public class HaftaIkiHatalar {
    
    // private int sayi = 5;  private sadece bu sınıf içerisinden bir değişkene erişebilir. Guard ise sadece bulunduğu paketten erişime hazır.
    
    // public static final int SAYI_BIR = 3; final anlamı bu değeri atadığımızda bir daha değiştirilmiyor.
    
 public static final double PI_SAYISI = 3.14159;
 private static int sayiBir = 1;
 private  int sayiIki = 2;
    
public static void main(String[] args) { // main küçük yazılır ve  void(geri veri döndürmüyor) şeklinde yazılır.
     System.out.println("Hafta 2 - İlk program."); // çift tırnak ile açılıp bitirilir parantez dışında da noktalı virgül ile bitirilir.
     // System.out.println(1 / 0);  Sayının 0 a bölünümü tanımsızdır o yüzden hata verir.

     System.out.println("C   ->   F");
     System.out.println("60 C " + ((9.0 / 5) * 60 + 32 ) + "F"); 
     double bölen = 9.0;
     int bölünen = 5;
     System.out.println(bölen / bölünen);
     System.out.println(PI_SAYISI + " " +  sayiBir);
     
     HaftaIkiSınıf yasYazdırma = new HaftaIkiSınıf();
     yasYazdırma.yasıYazdır();
}

public void sayiYazdir() {
         System.out.println("Sayı : " + sayiIki );
    }
    
}
