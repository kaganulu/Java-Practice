/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kaganulu
 */
public class HaftaIkiSınıf {
    
    private int yas = 20;
    
    public void yasıYazdır() {
         System.out.println("Yaş : " + yas );
    }
    
}
