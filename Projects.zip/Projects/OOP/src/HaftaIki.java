/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Hafta iki ders kodları
 * @author Kağan Ulu
 */
public class HaftaIki {
    /**
    * Başlangıç noktası
    * @param args Başlangıç Parametresi
    */
    public static void main(String[] args) {
             // Yorum satiri
             System.out.println("Hafta iki ders kodları.");
             
             System.out.println(" abc  "  +  100);
             
             int sayi = 100 ;
             System.out.println(sayi);
             sayi++;
             System.out.println(sayi);
             sayi--;
             System.out.println(sayi);
             
           System.out.println(HaftaIkiHatalar.PI_SAYISI);
                   
                  
    
    }
}
