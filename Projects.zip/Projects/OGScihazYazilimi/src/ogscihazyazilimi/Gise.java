/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ogscihazyazilimi;

/**
 *
 * @author kaganulu
 */
public class Gise {
    OGSBulundurur liste[];
    int i ;

    public Gise(){

        liste = new OGSBulundurur[ 20 ];

        i= 0 ;

    }

    void odemeAl(OGSBulundurur v){

        liste[i++] = v;

        v.odeme();

    }
    
}
