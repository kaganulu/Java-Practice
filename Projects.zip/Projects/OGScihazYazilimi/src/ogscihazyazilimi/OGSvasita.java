/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ogscihazyazilimi;

/**
 *
 * @author kaganulu
 */
public class OGSvasita implements OGSBulundurur{
    int bakiye;
    int ucret;

    @Override
    public int odeme() {
        bakiye -=ucret;
        
        return bakiye;
    }
    
    
}
