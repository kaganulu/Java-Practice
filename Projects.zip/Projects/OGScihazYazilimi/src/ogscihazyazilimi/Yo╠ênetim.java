/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ogscihazyazilimi;

/**
 *
 * @author kaganulu
 */
public class Yönetim {
    public void raporla(Gise g){

        int toplam = 0 ;

        for ( int i = 0 ;i<g.i;i++){

            System.out.println(((OGSvasita)g.liste[i]).ucret);

             toplam += (((OGSvasita)g.liste[i]).ucret);

        }

        System.out.println("Toplam : " +toplam);

    }
}
