/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metindekikelimesayisi;

/**
 *
 * @author kaganulu
 */
public class MetindekiKelimeSayisi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String s = "     Final Sınavı Çarşamba Günü!     ";
        kelime(s);
    }

    private static void kelime(String s) {
        int kelimeSayac = 1;
        int i = 0;
        if (s.charAt(0) == ' ') {
            while (s.charAt(i) == ' ') {
                i++;
            }
        }
        try {
            for (i = i; i < s.length(); i++) {

                if (s.charAt(i) == ' ' && s.charAt(i + 1) != ' ') {
                    kelimeSayac++;
                }
            }
        } catch (Exception ex) {
        }

        System.out.println("Cümleniz " + kelimeSayac + " tane kelimeden oluşur");
    }
}
