/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tkm2;

/**
 *
 * @author kaganulu
 */
public class Win {
    Oyuncu x = new Oyuncu();
    Oyun y = new Oyun();
    private int user = x.oyuncu();
    private int pc = y.Oyun();
    
    public void Win(){
        if (user == pc) {
            System.out.println("Berabere!");
        }
        // tas - makas
        else if (user == 0 && pc == 2){
            System.out.println("Oyuncu Kazandı!");
        }
        // kagit - tas
        else if (user == 1 && pc == 0){
            System.out.println("Oyuncu Kazandı!");
        }
        // makas - kagit
        else if (user == 2 && pc == 1){
            System.out.println("Oyuncu Kazandı!!");
        }
        else{
            System.out.println("Bilgisayar Kazandı!!");
        }
    }
}
