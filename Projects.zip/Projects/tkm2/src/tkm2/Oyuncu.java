/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tkm2;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Oyuncu {
    public int oyuncu(){
        Scanner s = new Scanner(System.in);
        System.out.println("Hangisini Seçmek istiyorsun? 0-[T],1-[K],2-[M]");
        int tercih = s.nextInt();
        
        return tercih;
    }
}
