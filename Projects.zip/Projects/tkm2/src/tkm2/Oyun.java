/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tkm2;

import java.util.Random;

/**
 *
 * @author kaganulu
 */
public class Oyun {
    public int Oyun(){
        Random r = new Random();
        int tercih = r.nextInt(3);
        System.out.println("oyun" +tercih);
        return tercih;
    }
    
    
}
