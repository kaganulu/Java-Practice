/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;

/**
 *
 * @author kaganulu
 */
public class Final {

    
    public static void main(String[] args) {
        // TODO code application logic here
      
    }
    public boolean deneme(String s1, String s2){
        int counter = 0;
    for ( int i = 0; i< s1.length(); i++ ) {
          if ( s1.charAt( i ) == s2.charAt( 0 ) ) {
              counter = 0;
              for ( int j = 0; j < s2.length(); j++ ) {
                  if ( s1. charAt( j + i ) == s2.charAt( j ) ) {
                     counter++;
                  } else {
                    break;
                 }
             }
             if ( counter == s2.length() ) {
                 return true;
             }
         }
     }
     return false;
    }
}
