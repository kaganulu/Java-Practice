/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gecmissorularıtekrar;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class GecmisSorularıTekrar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /*       System.out.println("Kaç tane yıldız girmek istersiniz?");
        Scanner scan = new Scanner(System.in);
        int yildizSayisi = scan.nextInt();
        
        for (int i = 0; i < yildizSayisi; i++) {
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        
        for (int i = yildizSayisi -1; i>0 ; i--) {
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
         */
        // Klavyeden girilen sayıyı pozitif tam sayı kabul ederek bu sayı ile 1000 
        // arasındaki asal sayıları bulup ekrana yazdıran program?   
        /*   
        Scanner sc = new Scanner(System.in);

        int girilenSayi = sc.nextInt();

        int min, max;

        int tamBolenSayiAdedi = 0;

        if (girilenSayi < 1000) {

            min = girilenSayi;

            max = 1000;

        } else {

            min = 1000;

            max = girilenSayi;

        }

        System.out.printf("%d ile %d arasindaki asal sayilar\n", min, max);

        for (int i = min; i < max; i++) {

            tamBolenSayiAdedi = 0;

            for (int j = 1; j <= min; j++) {

                if (i % j == 0) {

                    tamBolenSayiAdedi++;

                }

            }

            if (tamBolenSayiAdedi == 2) {

                System.out.printf("%d ", i);

            }

        }
         */
        //Kullanıcıdan aldiğınız sayı n olsun. n elemanlı bir dizi oluşturup,
        // bu diziyi random -1000 ile +1000 arasında sayilarla doldurun.
        //En kücük sayıyı bulana kadar kac defa güncelleme yapıldı bunu ekrana yazdırınız.
        System.out.println("Hangi sayıyı girmek istiyorsunuz?");
        Scanner scan = new Scanner(System.in);
        int aldıgınızSayi = scan.nextInt();
        int[] sayilar = new int[aldıgınızSayi];
        Random r = new Random(0);
        
        
        for (int i = 0; i < sayilar.length; i++) {
            sayilar[i] = r.nextInt(2001) - 1000;
        }
        System.out.println("Dizi oluşturuldu");
        
        int enKucuk = Integer.MAX_VALUE;
        int sayac = 0;
        
        for (int i = 0; i < sayilar.length; i++) {
            
            if(sayilar[i] < enKucuk){
                enKucuk = sayilar[i];
                sayac++;
            }
        }
        
        System.out.printf("En küçük sayı : %d\nGüncelleme sayısı: %d\n",enKucuk,sayac);
    }
}