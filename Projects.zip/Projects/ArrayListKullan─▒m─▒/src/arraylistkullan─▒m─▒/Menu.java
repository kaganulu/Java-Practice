/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylistkullanımı;

import java.util.ArrayList;
import java.util.*;

/**
 *
 * @author kaganulu
 */
public class Menu {
    public Menu(ArrayList<String> isimList,
                ArrayList<Integer> noList){
        Scanner sc = new Scanner(System.in);
        String m = "1 - Ekle \n"+
                   "2 - Sil \n"+
                   "3 - Güncelle \n"+
                   "4 - Goster \n"+
                   "5 - Çıkış";
        
        while(true){
            System.out.println(m);
            String islem = sc.nextLine();
            if (islem.equals("1")) {
                System.out.println("Numara Giriniz : ");
                int no = Integer.parseInt(sc.nextLine());
                System.out.println("İsim Giriniz : ");
                String isim = sc.nextLine();
                ekle(isimList,noList,no,isim);
                
                
            }else if (islem.equals("2")) {
              System.out.println("Numara Giriniz : ");
              int no = Integer.parseInt(sc.nextLine());
               sil(isimList,noList,no);
              
                
            }else if (islem.equals("3")) {
                System.out.println("Numara Giriniz : ");
                int no = Integer.parseInt(sc.nextLine());
                System.out.println("İsim Giriniz : ");
                String isim = sc.nextLine();
                guncelle(isimList,noList,no,isim);
                
            }else if (islem.equals("4")) {
                ekranaYaz(isimList,noList);
                
            }else if (islem.equals("5")) {
                break;
                
             
            }else {
                System.out.println("Yanlış değer ");
            }
            
        }
        
       
        
    }
    
     private void ekle(ArrayList<String> isimList,
                          ArrayList<Integer> noList,
                          int no,
                          String isim){
            isimList.add(isim);
            noList.add(no);
        }
     
     private void ekle(ArrayList<String> isimList,
                          ArrayList<Integer> noList,
                          int index,
                          int no,
                          String isim){
         isimList.add(index,isim);
         noList.add(index,no);
         
     }
     
     private void sil(ArrayList<String> isimList,
                      ArrayList<Integer> noList,
                      int no){
         
         int index = -1;// kullanıcının girdiği numara yoksa -1 girmeye çalışsın hata versin
         for (int i = 0; i < isimList.size(); i++) {
             if (no == noList.get(i)) {
                 index = i;
                 break;
                 
             }
         }
         isimList.remove(index);
         noList.remove(index);
         
     }
     
   private void ekranaYaz(ArrayList<String> isimList,
                          ArrayList<Integer> noList){
       
       for (int i = 0; i < isimList.size(); i++) {
           System.out.println(noList.get(i)+
                       "numaralı öğrenci : " +
                        isimList.get(i));
           
       }
       
   }
   
   private void guncelle(ArrayList<String> isimList,
                          ArrayList<Integer> noList,
                          int no,
                          String isim){
       
       int index = -1;// kullanıcının girdiği numara yoksa -1 girmeye çalışsın hata versin
         for (int i = 0; i < isimList.size(); i++) {
             if (no == noList.get(i)) {
                 index = i;
                 break;
                 
             }
         }
       sil(isimList,noList,no);
       ekle(isimList,noList,index,no,isim);
       
   }
     
    
}
