/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package methoddevam;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class MethodDevam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        ornekSoru();

        

    }
    /* verilen 2 sayi arasında rastgele sayilardan olusan 1000 elemanlı

    bir dizide girilen 3. sayidan kac adet oldugunu ve bunların pozisyonlarını

    array olarak donduren bir metod yazınız.

  method 1 - Random array olusturacak

  method 2 - array yazdıracak

  method 3 - verilen sayindan arrayde kac adet var ve bu sayiların pozisyonlarını

  bir array olarak geri dondurecek.

  */

    private static void ornekSoru() {
        int baslangic = 10, bitis = 100, elemanAdedi = 1000, sayi = 55;
        int[] sayilar = randomDiziOlustur(elemanAdedi, 10, 100, true);
        int[] pozisyonlar = pozisyonTara(sayilar,sayi);
        diziYazdır(pozisyonlar, "Eşleşen sayıların pozisyonları");
    }

    private static int[] randomDiziOlustur(int diziUzunlugu, int min, int max, boolean maxDahilmi) {
        Random r = new Random(0);
        int[] yeniArray = new int[diziUzunlugu];
        int randomParametresi = maxDahilmi ? max - min + 1 : max - min;
        
        for (int i = 0; i < diziUzunlugu; i++) {
            yeniArray[i] = r.nextInt(randomParametresi) + min;
        }
        return yeniArray;
    }

    private static int[] pozisyonTara(int[] sayilar, int sayi) {
        int cntr = 0;
        int[] pozisyonlar = {};    // bu sayıdan kaç tane var bilmediğimiz için önce boş bir array oluşturuyorum
        for (int i = 0; i < sayilar.length; i++) {
            if (sayilar[i] == sayi) {
                pozisyonlar = arrayGenislet(pozisyonlar);
                pozisyonlar[cntr] = i;
                cntr++;
            }
            
        }
        System.out.println("Bulunan eleman sayısı: " +cntr);
        return pozisyonlar;
    }

    private static int[] arrayGenislet(int[] eskiArray) {
        int[] yeniArray = new int[eskiArray.length + 1];
        for (int i = 0; i < eskiArray.length; i++) {
            yeniArray[i] = eskiArray[i];
            
        }
        return yeniArray;
    }

    private static void diziYazdır(int[] dizi, String metin) {
         System.out.println(metin);
        for (int i = 0; i < dizi.length; i++) {
            System.out.printf("dizi[%d] = %d\n", i, dizi[i]);
        }
    }
    
   
}
