/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telafıders;

/**
 *
 * @author kaganulu
 */
public class TelafıDers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        int tamBölenSayısı = 0;

        for (int i = 55;  <= 100; i++) {
            tamBölenSayısı = 0;
            for (int j = 1; j <= i; j++) {
                if (i % j == 0) {
                    tamBölenSayısı++;
                }
            }
            if (tamBölenSayısı > 2) {
                System.out.println(i + " sayısı asal değil. ");
            } else {
                System.out.println(i + " bir asal sayıdır. ");
            }
        }

    }
}
