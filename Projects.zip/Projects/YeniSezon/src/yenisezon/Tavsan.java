/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yenisezon;

import java.util.Random;

/**
 *
 * @author kaganulu
 */
public class Tavsan extends Hayvan{
    public Tavsan(int location){
        super(location);
    }
    Random r = new Random();
    
    public void kos(){
        int zar = r.nextInt(6);
        if (zar == 0 || zar == 1 || zar == 2) {
            this.location  +=2;
        }
        if (zar == 3) {
            
        }
        if (zar == 4 || zar == 5) {
            this.location --;
        }
    }
    
      
}
