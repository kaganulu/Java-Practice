/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yenisezon;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class YeniSezon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Tavsan tav = new Tavsan(0);
        Kaplumbaga kap = new Kaplumbaga(0);
        
        while(tav.getLocation()<100 && kap.getLocation()<100){
            tav.kos();;
            kap.kos();
        }if (tav.getLocation()>=100 && kap.getLocation()>=100) {
            System.out.println("Berabere Kaldılar.");
        }else if (tav.getLocation()>=100) {
            System.out.println("Tavşan Kazandı.");
            
        }else if (kap.getLocation()>=100) {
             System.out.println("Kaplumbağa Kazandı.");
        }
               
       System.out.println("Aralarındaki Fark " + (tav.getLocation() - kap.getLocation()));
       
       
    }
    
}
