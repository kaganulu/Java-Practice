/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yenisezon;

/**
 *
 * @author kaganulu
 */
public class Hayvan {
    protected int location;
    
    public Hayvan(int location){
        this.location = location;
    }

    public int getLocation() {
        return location;
    }

    public void setLocation(int location) {
        this.location = location;
    }
    
    

   
    
    
    
}
