/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaswitchcase;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class JavaSwitchCase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        /*

    Puan 	Dönem Ders Notu	Katsayı	Statü

    80-100	A	4,00	Başarılı

    60-79	B	3,50	Başarılı

    40-59	C	3,00	Başarılı

    >=39 	F	0,00	Başarısız- Kalır
 */  
     
        //3 değişken tanımlayalım vize 1 , vize 2 ve final. vize 1 veya vize 2 den büyük olanın %40ı finalin %60i
        int vize1, vize2, vizeNotu, finalNotu;

        Scanner imput = new Scanner(System.in);

        System.out.print("Vize 1 notunu girin : ");
        vize1 = imput.nextInt();
        System.out.print("Vize 2 notunu girin : ");
        vize2 = imput.nextInt();
        System.out.println("Final Notunu girin");
        finalNotu = imput.nextInt();

        if (vize1 > vize2) {
            vizeNotu = vize1;
        } else {
            vizeNotu = vize2;
        }
        float ağırlıklıNot = (float) ((vizeNotu * 0.4) + (finalNotu * 0.6));
        System.out.println("Ağırlıklı not :" + ağırlıklıNot);
        char harfNotu;
        if (ağırlıklıNot >= 80) {
            harfNotu = 'A';
        } else if (ağırlıklıNot < 80 && ağırlıklıNot >= 60) {
            harfNotu = 'B';
        } else if (ağırlıklıNot < 60 && ağırlıklıNot >= 40) {
            harfNotu = 'C';
        } else {
            harfNotu = 'F';
        }
        System.out.println("Harf Notu :" + harfNotu);
        switch (harfNotu) {
            case 'A':
                System.out.println("Ortalama etkisi 4.00 - Başarılı");
                break;
            case 'B':
                System.out.println("Ortalama Etkisi 3.50 - Başarılı");
                break;
            case 'C':
                System.out.println("Ortalama Etkisi 3.00 - Başarılı");
                break;
            case 'F':
                System.out.println("Ortalama Etkisi 0.00 - Başarısız");
                break;
            default:
                System.out.println("Harf Notu bulunamadı");
                break;
        }
         
      

    }
}
