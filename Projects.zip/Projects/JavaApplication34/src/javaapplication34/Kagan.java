/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication34;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Kagan extends Insan implements IEylem,IKart{
    private String soyIsim;
    private String kimlik;
    private String pass;
    private String tcno;
    private String bankKart;
    private String ulasimKart;
    private double bakiye;
    private String ehliyet;

    public Kagan(String soyIsim,String anneAd, String babaAd, int boyCM, double kilo, double varlik) {
        super(anneAd, babaAd, boyCM, kilo, varlik);
        this.soyIsim = soyIsim;
        this.anneAd = anneAd;
        this.tcno = this.sayi(11);
        this.kimlikOlustur(this.toString(),this.soyIsim,babaAd,anneAd,this.tcno);
        this.pasaportOlustur(this.toString(), this.soyIsim, anneAd, babaAd, this.tcno);
        this.bankOlustur(this.toString(),this.soyIsim, this.sayi(16), this.sayi(3), this.getVarlik());
        this.ulasimOlustur(this.sayi(11), 50);
        this.ehliyetOlustur(this.toString(),this.soyIsim, "B", 100);
        
    }

   
     private String sayi(int basamak){
        String bSayi = "";
        Random r = new Random();
        for (int i = 0; i < basamak; i++) {
            int x = r.nextInt(10);
            bSayi += x;
        }
        return bSayi;
    }

    @Override
    public void yemekYe(int kalori) {
         if(kalori >= 1000){
            this.kilo += kalori/1000.0;
            System.out.println("Ana öğün yendi. Yeni kilonuz = "+getKilo());
        }
        else{
            this.kilo += kalori/1200.0;
            System.out.println("Atıştırıldı. Yeni kilonuz = "+getKilo());
        }
    
    }

    @Override
    public void sporYap(int saat) {
        System.out.println("Yapilan spor cesidini giriniz\n"
                + "1 - Koşu\n"
                + "2 - Agirlik\n"
                + "3 - Bisiklet\n");
        Scanner sc = new Scanner(System.in);
        String cevap = sc.nextLine();
        switch(cevap){
            case "1":
                this.kilo -= saat*0.4;
                System.out.println("Spor yapıldı. Yeni kilonuz = "+getKilo());
                break;
            case "2":
                this.kilo -= saat*0.8;
                System.out.println("Spor yapıldı. Yeni kilonuz = "+getKilo());
                break;
            case "3":
                this.kilo -= saat*0.6;
                System.out.println("Spor yapıldı. Yeni kilonuz = "+getKilo());
                break;
            default : 
                System.out.println("Yanlış değer girdiniz. Spor yapılamadı.");
        }
    }

    @Override
    public void calis(int saat, String meslek) {
        if(meslek.equals("Ogretmen")){
            this.varlik += saat*30;
            System.out.println("Yeni varliginiz = "+getVarlik());
        }
        if(meslek.equals("Mühendis")){
            this.varlik += saat*45;
            System.out.println("Yeni varliginiz = "+getVarlik());
        }
        if(meslek.equals("Avukat")){
            this.varlik += saat*42;
            System.out.println("Yeni varliginiz = "+getVarlik());
        }
    }

    @Override
    public void hobiYap(String hobi) {
        if(hobi.equals("muzik")){
            this.varlik -= 200;
            System.out.println("Müzik dinlemeye gitti. Yeni varlik = "+getVarlik());
        }
        if(hobi.equals("spor")){
            this.varlik -= 100;
            System.out.println("Spora gitti. Yeni varlik = "+getVarlik());
        }
        if(hobi.equals("PC oyun")){
            this.varlik -= 600;
            System.out.println("Pc oyun oynamaya gitti. Yeni varlik = "+getVarlik());
        }
        if(hobi.equals("yuzme")){
            this.varlik -= 100;
            System.out.println("Yuzmeye gitti. Yeni varlik = "+getVarlik());
        }
        if(hobi.equals("alisveris")){
            this.varlik -= 1000;
            System.out.println("Alısverise gitti. Yeni varlik = "+getVarlik());
        }
        if(hobi.equals("tatil")){
            this.varlik -= 6200;
            System.out.println("Tatile gitti. Yeni varlik = "+getVarlik());
        }
        
    }

    @Override
    public void kimlikOlustur(String ad, String soyad, String anneAd, String babaAd, String tcno) {
        kimlik = tcno+"\n"
                +soyad +"\n"
                +ad +"\n"
                +babaAd +"\n"
                +anneAd + "\n";
    
    }

    @Override
    public void kimlikGoster() {
        System.out.println(kimlik);
    }

    @Override
    public void ehliyetOlustur(String ad, String soyad, String sinif,int puan) {
         this.ehliyet = ad + " " + soyad + "\n" + "Sinifi = " 
                + sinif +"\n" + "Puan = " + puan;
        
    }

    @Override
    public void ehliyetGoster() {
        System.out.println(ehliyet);
    }

    @Override
    public void bankOlustur(String ad, String soyad, String kartNo, String cvc,double para) {
        bankKart = kartNo +
                "\n"+ ad +
                "\n"+ soyad +
                "\n"+ cvc;
    }

    @Override
    public void bankGoster(double miktar) {
        Scanner sc = new Scanner(System.in);
        String menu = "1 - Miktari yatir\n"
                + "2 - Miktari kullan\n"
                + "3 - Hesap durmunu goruntule\n"
                + "x - Cikis yap";
        boolean kontrol = true;
        while(kontrol){
        System.out.println(menu);
        String islem = sc.nextLine();
        if(islem.equals("1")){
            this.varlik += miktar;
        }
        else if(islem.equals("2")){
            if(this.getVarlik() - miktar >= 0){
               this.varlik -= miktar; 
            }
            else{
                System.out.println("yeterli bakiye yoktur.");
            }
            kontrol = false;
        }
        else if(islem.equals("3")){
            System.out.println(bankKart+this.getVarlik());
        }
        else if(islem.equals("x")){
            System.out.println("Cikis yapılıyor");
            //break;
            kontrol = false;
        }
        else{
            System.out.println("Yanlis giris yaptiniz");
        }
        }
        
    }

    @Override
    public void ulasimOlustur(String kartNo, double bakiye) {
        this.ulasimKart = kartNo;
        this.bakiye = bakiye;
    }

    @Override
    public void ulasimGoster() {
          Scanner sc = new Scanner(System.in);
        String menu = "1 - Toplu tasima kullan\n"
                + "2 - para yukle";
        String islem = sc.nextLine();
        if(islem.equals("1")){
            if(this.bakiye - 3.85 >=0){
                this.bakiye -= 3.85;
            }
            else{
                System.out.println("Yeterli bakiye yok!");
            }
            System.out.println("Kalan bakiyeniz = "+this.bakiye);
        }
        else if (islem.equals("2")){
            System.out.println("Eklemek istediğiniz miktarı giriniz");
            int x = sc.nextInt();
            this.bakiye += x;
            System.out.println("Bakiyeniz = "+this.bakiye);
        }
        else{
            System.out.println("Yanlis deger girdiniz.");
        }
    }

    @Override
    public void pasaportOlustur(String ad, String soyad, String anneAd, String babaAd, String tcno) {
         Random r = new Random();
        if(r.nextInt(100)<60){
            pass = tcno+"\n"
                +soyad +"\n"
                +ad +"\n"
                +babaAd +"\n"
                +anneAd + "\n";
        }
        else{
            pass = "Pasaport yoktur";
        }   
    }

    @Override
    public void pasaportGoster() {
        System.out.println(pass);
    }
    
    
}
