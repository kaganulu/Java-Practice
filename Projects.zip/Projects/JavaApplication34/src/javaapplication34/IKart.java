/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication34;

/**
 *
 * @author kaganulu
 */
public interface IKart {
    void kimlikOlustur(String ad, String soyad, String anneAd, String babaAd, String tcno);
    void kimlikGoster();
    void ehliyetOlustur(String ad, String soyad, String sinif,int puan);
    void ehliyetGoster();
    void bankOlustur(String ad, String soyad, String kartNo, String cvc,double para);
    void bankGoster(double miktar);
    void ulasimOlustur( String kartNo,double bakiye);
    void ulasimGoster();
    void pasaportOlustur(String ad, String soyad, String anneAd, String babaAd, String tcno);
    void pasaportGoster();
}
