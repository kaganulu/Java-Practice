/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication34;

/**
 *
 * @author kaganulu
 */
public abstract class  Insan {
    protected String anneAd;
    protected String babaAd;
    protected int boyCM;
    protected double kilo;
    protected double varlik;
    
    
    protected Insan(String anneAd, String babaAd,int boyCM,double kilo,double varlik){
        this.anneAd=anneAd;
        this.babaAd=babaAd;
        this.boyCM=boyCM;
        this.kilo=kilo;
        this.varlik=varlik;
        
    }
    
    
    protected String getAnneAd(){
        return this.anneAd;
    }
    protected String getbabaAd(){
        return this.babaAd;
    }

    protected int getBoyCM() {
        return this.boyCM;
    }

    protected double getKilo() {
        return this.kilo;
    }

    protected double getVarlik() {
        return this.varlik;
    }
    
}
