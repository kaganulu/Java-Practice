/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication34;

/**
 *
 * @author kaganulu
 */
public interface IEylem {
    void yemekYe(int kalori);
    void sporYap(int saat);
    void calis(int saat, String meslek);
    void hobiYap(String hobi);
    
    
}
