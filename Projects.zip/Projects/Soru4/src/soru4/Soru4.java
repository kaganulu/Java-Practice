/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soru4;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author kaganulu
 */
public class Soru4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random r = new Random();
        ArrayList<Integer> aList = new ArrayList<>();
        for (int i = 0; i < 25; i++) {
            aList.add(1 + r.nextInt(9999));

        }
        rakamTopla(aList.get(r.nextInt(25)));
       

    }

    private static void rakamTopla(int x) {
        System.out.println("Sayı: " + x);
        int k = x;
        int toplam = 0;
        while (k != 0) {
            toplam += k % 10; // Sayının En sondaki basamağındaki bulunan rakamı toplama ekledik
            k = k / 10;
        }

        System.out.println("Toplam: " + toplam);
        
        
        
        rakamTopla2(x);

    }

    private static void rakamTopla2(int x) {
        System.out.println("String Kullanarak Sayı :" +x);
        String sayiString = String.valueOf(x);

        int rakamlarToplam = 0;

        for (int i = 0; i < sayiString.length(); i++) {
            char basamak = sayiString.charAt(i);
            rakamlarToplam += Integer.parseInt(String.valueOf(basamak));

        }
        System.out.println("Rakamlar Toplamı: " + rakamlarToplam);

    }
}
