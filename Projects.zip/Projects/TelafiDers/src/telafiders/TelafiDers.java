/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telafiders;

/**
 *
 * @author kaganulu
 */
public class TelafiDers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int sayac = 0;
        for (int sayi = 55; sayi <= 100; sayi++) {
            int kontrol = 0;
            for (int i = 55; i < sayi; i++) {
                if (sayi % i == 0) {
                    kontrol = 55;
                    break;
                }
            }

            if (kontrol == 0) {
                System.out.print(sayi + "\n");
                sayac++;
            }
        }
    }
}
