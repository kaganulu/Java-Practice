/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorular;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Sorular {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // 1- Klavyeden girilen 2 sayının ortak bölenlerinin en büyüğüünü bulan kodu yazınız.
        /*
        int sayi1, sayi2;

       Scanner sc = new Scanner(System.in);

        System.out.println("Sayi 1 :");

        sayi1 = sc.nextInt();

        System.out.println("Sayi 2 :");

        sayi2 = sc.nextInt();

        int obeb = 0;

        for (int i = 1; i <= sayi1 && i <= sayi2; i++) {

            if (sayi1 % i == 0 && sayi2 % i == 0) {

                obeb = i;

            }

        }

        if (obeb != 0) {

            System.out.println("OBEB : " + obeb);

        } else {

            System.out.println("Ortak katı yoktur");

        }
         */
        // 2- İsminizin her bir karakterinin numara karşılığını ve isminizdeki karakterlerin toplamını yazınız. (A = 1 olacak)
        /* 
        Scanner sc2 = new Scanner(System.in);
        char c;
        int toplamDeger = 0;
        int deger = 0;
        int kucukHarf = (int) 'a' - 1;
        int buyukHarf = (int) 'A' - 1;
        System.out.println("İsminizin karakterlerini giriniz.");
        while (sc2.hasNext()) {
            System.out.println("Harf giriniz.");
            c = sc2.next().charAt(0);
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) {
                break;
            }

            if (c >= 'a' && c <= 'z') {
                deger = (int)c - kucukHarf;
                
            } else {
                deger = (int)c - buyukHarf;
                
            }

            System.out.println("Girilen karakter: " + c + " , sıra numarası:" + deger);
            toplamDeger+=deger;

        }
        System.out.println("Toplam deger : " + toplamDeger);
         */
 /* 
        
        a)  1         b)    #     c) #######  d) #######
        11             #   #       #     #       ##   ##
        101             # #        #     #       # # # #
        1001             #     ->  #     #  ->   #  #  #
        10001           # #        #     #       # # # #
        100001         #   #       #     #       ##   ##  
        1111111       #     #      #######       #######
        
    a)  Scanner satirGirdisi= new Scanner(System.in);
        System.out.println("Satir sayisi girin");
        int maxSatırSayısı = satirGirdisi.nextInt();
        
        for (int satir = 0; satir < maxSatırSayısı; satir++) {
            for (int sutun = 0; sutun <= satir; sutun++) {
                if (sutun == 0 || satir == maxSatırSayısı - 1 || satir == sutun) {
                    System.out.print("1");
                } else {
                    System.out.print("0");
                }
            }
            System.out.print("\n");
         */
     /*   int satır, stun;
        Scanner sc = new Scanner(System.in);
        System.out.println("Satir Sayisi :");
        satır = sc.nextInt();
        System.out.println("Stun Sayisi :");
        stun = sc.nextInt();
        int anlikSatir = 0, anlikStun = 0;

        while (anlikSatir < satır) { //satirlar
            anlikStun = 0;
            while (anlikStun < stun) { //stunlar
                if (anlikSatir == 0 || anlikStun == 0 || anlikSatir == satır - 1 || anlikStun == stun - 1) {
                    System.out.print("+");
                } else {
                    System.out.print(" ");
                }
                anlikStun++;
            }
            System.out.print("\n");
            anlikSatir++;
     }
/*  
        String şablon;
        int kaçKez;

        Scanner scan = new Scanner(System.in);

        System.out.print("Şablonu Giriniz : ");
        şablon = scan.nextLine();

        System.out.print("Kaç kez yazdırılması gerektiğini giriniz : ");
        kaçKez = scan.nextInt();

        for (int i = 1; i <= kaçKez; i++) {

            System.out.println();

            if (i == 1 || i == kaçKez) {

                for (int j = 1; j <= kaçKez; j++) {

                    System.out.print(şablon + " ");

                }
            } else {

                for (int k = 1; k <= kaçKez; k++) {

                    if (k == 1 || k == kaçKez) {

                        System.out.print(şablon + " ");

                    } else {

                        System.out.print("  ");

                    }

                }

            }
 */
            // d)
            for (int row = 1; row <= 9; row++) {

                for (int col = 1; col <= 9; col++) {

                    if (row == 1 || row == 9 || col == 1 || col == 9 || row == col || row + col == 9 + 1) {
                        System.out.print("*");
                    } else {
                        System.out.print(" ");
                    }

                }
                System.out.println();
            }

        }
    }

