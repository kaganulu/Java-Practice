/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soru14;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Soru14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         ArrayList<Integer> aList = new ArrayList<>();
         aList.add(5);
         aList.add(3);
         aList.add(6);
         aList.add(5);
         aList.add(2);
         aList.add(1);
         
         System.out.println("Hangi sayının listede kaç tane olduğunu öğrenmek istersiniz? : ");
         int sonuc = tekrar(aList,sc.nextInt());
         System.out.println("Sonuç : "+sonuc);
         
         
    }

    private static int tekrar(ArrayList<Integer> aList, int i) {
        int sayac = 0;
        for (Integer element : aList) {
            if (element == i) sayac++; {
                
            }
        
        }
         return sayac;
    }
    
}
/* İki türlü for kullanabiliriz
for (int i = 0; i < aList.size(); j++) {
                if (aList.get(i) == i) sayac++; {
                
            }
              }
 */