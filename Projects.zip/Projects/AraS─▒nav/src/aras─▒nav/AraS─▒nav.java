/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arasınav;

import java.util.Random;

/**
 *
 * @author kaganulu
 */
public class AraSınav {

    public static void main(String[] args) {

           vizeS5();
    }
    
       /*
    -25(dahil) ile 215(dahil) aralarında rastgele tamsayÄ±lardan oluÅŸsan 
    10 elemanlı bir dizideki her bir tek sayı için kaç basamaklı olduğunu 
    hesaplayınız, dizideki tek sayiların toplamda kac basamaklı olduğunu 
    ekrana yazdıran kodu yazınız
         */ 
    
    private static void vizeS5() {
        Random r = new Random(0);
        int min = -25;
        int max = 215;
        int[] sayilar = new int[10];
        for (int i = 0; i < sayilar.length; i++) {
            sayilar[i] = r.nextInt(max - min + 1) + min;
        }
        int degerlendirilenSayi;
        int toplamTekSayiBasamakMiktarı = 0, tekSayiBasamakMiktari = 0;
        for (int i = 0; i < sayilar.length; i++) {
            tekSayiBasamakMiktari = 0;
            if (sayilar[i] % 2 != 0) {
                //değişken = koşul ?(dogruysa) : (yanlışsa);
                degerlendirilenSayi = sayilar[i] < 0 ? sayilar[i] * -1 : sayilar[i];
                while (degerlendirilenSayi > 0) {
                    tekSayiBasamakMiktari++;
                    degerlendirilenSayi /= 10;
                }
                System.out.printf("Sayi = %d, Basamak miktarı = %d\n", sayilar[i], tekSayiBasamakMiktari);
            }
            toplamTekSayiBasamakMiktarı += tekSayiBasamakMiktari;
        }
        System.out.println("Toplam Tek Sayı Basamak Adedi = " + toplamTekSayiBasamakMiktarı);

    }

}
