/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication58;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class JavaApplication58 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        /*  System.out.println("ilk rakamı giriniz: ");
        int a = s.nextInt();
        System.out.println("ikinci rakamı giriniz: ");
        int b = s.nextInt();
        System.out.println("Üçüncü rakamı giriniz: ");
        int c = s.nextInt();
        
        
        switch(a % b) {
           case 0:System.out.println(a-b);
           case 1: System.out.println(b-c);
           break;}
        System.out.println(b-c);
                
         */
 /* Scanner s = new Scanner(System.in);
        /* System.out.print("Enter a number: ");
        int n = s.nextInt();
        

        int t1 = 0, t2 = 1;
        System.out.print("First " + n + " terms: ");

        for (int i = 1; i <= n; ++i) {
            System.out.print(t1 + " ");

            int sum = t1 + t2;
            t1 = t2;
            t2 = sum;
        }
         */
        Scanner s = new Scanner(System.in);

        System.out.print("Faktöriyelini hesaplamak istediğiniz sayıyı giriniz: ");
        int sayi = s.nextInt();

        int sonuc = 1;
        int i = 1;
        do {
            sonuc *= i;
            i++;
        } while (i <= sayi);

        System.out.println(sayi + "! = " + sonuc);
    }
}
