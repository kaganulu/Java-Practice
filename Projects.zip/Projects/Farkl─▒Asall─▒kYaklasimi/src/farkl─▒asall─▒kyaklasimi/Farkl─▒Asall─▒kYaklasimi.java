/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package farklıasallıkyaklasimi;

/**
 *
 * @author kaganulu
 */
public class FarklıAsallıkYaklasimi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int boyut = 1000;
       
       boolean[] dizi = new boolean[boyut+1];
        for (int i = 0; i < dizi.length; i++) {
            dizi[i] = true;
        }
        asal(dizi);
        for (int i = 0; i < dizi.length; i++) {
            if (dizi[i] == true) System.out.println(i+ " asaldır. ");
        }
    }

    private static void asal(boolean[] d) {
        d[0] = false;
        d[1] = false;
        for (int i = 2; i < d.length; i++) {
            if (d[i]== true) {
                for (int j = i + i; j <d.length; j+=i) {
                    d[j]=false;
                }
            }
        }
    }
    
}
