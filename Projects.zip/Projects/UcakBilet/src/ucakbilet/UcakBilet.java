/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ucakbilet;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class UcakBilet {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Km birim fiyatı = 0.10$
        // 12 yaşından küçükse toplam fiyata %50 indirim
        // 12 ve 24 yaş arasındaysa %10 indirim
        // 65 yaşından büyükse %30 indirim
        // Gidiş-dönüş alırsa %20 indirim
        
        Scanner scan =new Scanner(System.in);
        int km,yas,tip;
        System.out.println("Mesafeyi giriniz : ");
        km = scan.nextInt();
        System.out.println(" Yaşınızı giriniz : ");
        yas = scan.nextInt();
        System.out.println("Yolculuk tipini seçiniz (1=Tek Gidiş , 2=Gidiş/Dönüş) : ");
        tip = scan.nextInt();
        
        double normalFiyat,yasIndirimi,tipIndirimi;
        if(km > 0 && yas > 0 && (tip==1 || tip==2)){
            
            normalFiyat = km * 0.10;
            if(yas < 12){
                yasIndirimi = normalFiyat * 0.5;// İndirim oranı
                normalFiyat = normalFiyat - yasIndirimi; // Fiyattan indirim payını çıkarttım
            }else if(yas >= 12 && yas <= 24){
                yasIndirimi = normalFiyat * 0.10;
                 normalFiyat -= yasIndirimi;
                
            }else if(yas >= 65){
                yasIndirimi = normalFiyat * 0.30;
                normalFiyat -= yasIndirimi;
            }else {
                yasIndirimi =0;
            }    
            
            if(tip == 2) {
                tipIndirimi = normalFiyat * 0.20;
                normalFiyat =(normalFiyat -tipIndirimi) * 2;
            }
            
            System.out.println("Bilet Tutarı : " + normalFiyat + "$" );
                
            
            
            
        }else {
            System.out.println("Girdiler değerler eksik veya yanlış lütfen tekrar deneyiniz. !");
        }
        
        
        
        
        
    }
    
}
