/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deneme;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Deneme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Kelimedeki tekrar eden harfleri bulma 
      /*   String sentence = "How many duplicates are there?";
        System.out.println(sentence);

        String characters = "";
        String duplicates = "";

        for (int i = 0; i < sentence.length(); i++) {
            String current = Character.toString(sentence.charAt(i));
            if (characters.contains(current)) {
                if (!duplicates.contains(current)) {
                    duplicates += current + " , ";
                }
            }
            characters += current;

        }
        System.out.println(duplicates);

     /*    // while döngüsü ile ters alma 
        int num = 1234, tersAl = 0;

        while (num != 0) {

            int digit = num % 10;
            tersAl = tersAl * 10 + digit;
            num /= 10;
        }
       System.out.println("Sayının tersi:  " + tersAl);
*/
     
        // For ile faktöriyel hesabı
       /*   System.out.println("Faktöriyelini almak istediğiniz sayıyı girin: ");
         Scanner scan = new Scanner(System.in);
         int num;
         num = scan.nextInt();
         long factorial = 1;
         for (int i = 1; i <= num; ++i) {
            // factorial = factorial * i;
            factorial *= i;
        }
        System.out.printf("Factorial of %d = %d", num, factorial);
      
       
       //Santigrat derece okuyan bir program yazın
        //  konsoldan çift değer alır, ardından bunu Fahrenheit'e dönüştürür ve
       // sonuç. Dönüşüm formülü aşağıdaki gibidir:
       // fahrenhayt = (9/5) * santigrat + 32
       
       Scanner imput = new Scanner(System.in);
       System.out.print("Santigrat cinsinden bir derece girin:");
       double celsius = imput.nextDouble();
       
       double fahrenheit = 9.0 / 5 * celsius + 32;
       
       System.out.println(celsius + "Celcius is " + fahrenheit);
        */
       
       // (Bir silindirin hacmini hesaplayın) Bir silindirin yarıçapını ve uzunluğunu okuyan ve aşağıdakileri kullanarak alanı ve hacmi hesaplayan bir program yazın
       //    alan = yarıçap * yarıçap * pi
          //   hacim = alan * uzunluk
     
       /*   
          Scanner input = new Scanner(System.in);
          final double PI = 3.14159265359;
          
          System.out.print("Bir silindirin yarıçapını ve uzunluğunu girin: ");
          double yarıcap = input.nextDouble();
          double uzunluk = input.nextDouble();
         
          double alan = yarıcap  * yarıcap  * PI;
          double hacim = alan  * uzunluk;
          
          System.out.println("Alanı: " +alan);
          System.out.println("Hacmi: " +hacim);
          
          
          //Finansal uygulama: ipuçlarını hesaplayın) Ara toplamı okuyan bir program yazın
          // ve ikramiye oranı, ardından ikramiye ve toplamı hesaplar. Örneğin,
         //  kullanıcı ara toplam için 10 ve ikramiye oranı için% 15 girerse, program 1.5 $ gösterir
          //  ikramiye ve toplam 11,5 dolar.
          
          System.out.println("Aldığınız ara toplamı ve ikramiyeyi giriniz:");
          Scanner input = new Scanner(System.in);
          double araToplam = input.nextDouble();
          double ikramiyeOrani = input.nextDouble();
          
          double ikramiye = araToplam * (ikramiyeOrani / 100);
          double toplam = araToplam + ikramiye;
          
          System.out.println("İkramiye $ " + ikramiye + " ve  Toplam " + toplam);
         */
       
        // 0 ile 100 arasında hem 3 e hem 7 ye bölünebilen sayılar
       /*  
        for (int i = 0; i < 100; i++) {
            if (i % 3 == 0 && i % 7 == 0){
                System.out.println("3 e ve 7 ye bölünebilen sayılar: " +i);
            } 
        }
          for ( int i = 0; i < 4; i++){
              
             System.out.println("" +((i+1) * 21));
               
          }
          */
       
        
        Scanner sc = new Scanner(System.in);
        int a,b,c,z,top,sayac;
        top = 0;
        sayac = 0;
        
        for (int i = 0; i < 2; i++) {
            
        System.out.println("a sayısını giriniz:");
        a = sc.nextInt();
        System.out.println("b sayısını giriniz:");
        b = sc.nextInt();
        System.out.println("c sayısını giriniz:");
        c = sc.nextInt();
        
        z = a - 5 * b + 4 * c;
            if (z > 0) {
                top += z;
                sayac ++;
                
            }
            
        }
        double ort = top/sayac;
        System.out.println("Ortalama "+ ort);
       
    }
}
