/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haftaıkicevaplar;
import java.util.Scanner;
/**
 *
 * @author kaganulu
 */
public class Kosullar {
     public static void main(String[] args) {
         
         int sayi1 = 3, sayi2 = 5;
         
         
         double sayi3 = (double) sayi1;
         System.out.println("Double olarak : " + sayi3);
         sayi3 = 128.83219;
         System.out.println(sayi3 + "un int karşılığı: " + (int) sayi3);
         
         System.out.println(" Block if ");
         if (sayi1 < sayi2) {
             System.out.println(" Sayı 1 > Sayı 2 ");
             System.out.println(" Sayı 1 > Sayı 2 ");
             
         }
         
         System.out.println(" Blocksuz ");
         if (sayi1 > sayi2) 
             System.out.println(" Sayı 1 > Sayı 2 ");
             System.out.println(" Her koşulda çalışan kod parçası ");
             
             
         System.out.println("Dur");
         
      // Klavyeden girilen yılın artık yıl olup olmadığını kontrol ediniz.
      /* 
       4e tam bölünen, 100e tam bölünemeyen, 400e tam bölünen ve 4000 e tam bölünemeyen.
     */
     /* System.out.print("Bir yıl girin:");
      Scanner imput =new Scanner(System.in);
      int yil = imput.nextInt();
      
      boolean artikYil = false;
      if(yil % 4 == 0)
        {
            if(yil % 100 == 0){
            if (yil % 400 == 0){
            if ( yil % 4000 == 0){
                artikYil = false;
                
            } else {
                artikYil = true;
            }
                
            } else{
                artikYil = false;
            }
                
            } else {
                artikYil = true;
            }
            
            
            
      }  else { 
         artikYil = false;
         }
       
           
                
        if(artikYil==true)
            System.out.println(yil + " artık bir yıldır.");
        else
            System.out.println(yil + " artık bir yıl değildir.");
      */
     
       Scanner input = new Scanner (System.in);
        System.out.println("Yıl giriniz");
        int girdi = input.nextInt();
        boolean artikYil = false;
        
        if (girdi % 4000 == 0) {
            artikYil = false ;
        } else if (girdi % 400 == 0) {
            artikYil = true;
        } else if (girdi % 100 == 0) {
            artikYil = false;
        } else if (girdi % 4 == 0) {
            artikYil = true;
        } else {
            artikYil = false;
        }
        System.out.println("Artik Yıl : "+ artikYil);
        
        // 55 ile 100 arasındaki asal sayılar 
         int tamBölenSayısı = 0;

       
    }
}

