/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haftaıkicevaplar;
 import java.util.Scanner;
/**
 *
 * @author kaganulu
 */
public class HaftaIkiCevaplar {
    enum Gunler {
        PAZARTESİ, SALI, ÇARŞAMBA, PERŞEMBE, CUMA ,CUMARTESİ, PAZAR
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       // Klavyeden yapılan saniye olarak verilen bir sayının kaç gün /saat / dakika / saniye olduğunu hesaplayınız
       /* 
       Scanner girilen=new Scanner(System.in);
       System.out.println("Kaç saniye üzerinden işlem yapalım");
       int saniye = girilen.nextInt();
       int dakika = saniye/60;
       int saat = dakika/60;
       int gün = saat/24;
       
       saat = saat%24;
       dakika = dakika%60;
       saniye = saniye%60;
       
       System.out.println(gün+ " gün " + dakika+ " dakika  " + saat + " saat  " + saniye + " saniye " );
        
       
       //Bu gün günlerden Salı ise 9643 gün sonra hangi günde oluruz?

         String[] days = {"pazartesi", "salı", "çarşamba", "perşembe", "cuma", "cumartesi", "pazar"};

        int kalanGun = 9643%7;

        String yeniGun = days[1 + kalanGun];

        System.out.println(yeniGun);
         */
       
       int baslangıcGünü = 1;
       int kalanGün = (9643 + baslangıcGünü) % 7;
       
       String sonuc = kalanGün == 0 ? Gunler.PAZARTESİ.toString() :
               kalanGün == 1 ? Gunler.SALI.toString() :
               kalanGün == 2 ? Gunler.ÇARŞAMBA.toString() : 
               kalanGün == 3 ? Gunler.PERŞEMBE.toString() : 
               kalanGün == 4 ? Gunler.CUMA.toString() : 
               kalanGün == 5 ? Gunler.CUMARTESİ.toString() : 
               kalanGün == 6 ? Gunler.PAZAR.toString() : "";
       
        System.out.println(sonuc);
      
       
         // Klavyeden girilen yilin artık yıl olması durumunu kontrol edin
        // sayı 4ün katı olmalı
        // sayı 100ün katı olmamalı
        // sayı 400ün katı olmalı
        // sayı 4000 in katı olmamalı
        // 4000 yili artık yıl değil, 1600 yılı artik yil, 1900 yili arık yıl değil
        Scanner input = new Scanner (System.in);
        System.out.println("Yıl giriniz");
        int girdi = input.nextInt();
        boolean artikYil = false;
        
        if (girdi % 4000 == 0) {
            artikYil = false ;
        } else if (girdi % 400 == 0) {
            artikYil = true;
        } else if (girdi % 100 == 0) {
            artikYil = false;
        } else if (girdi % 4 == 0) {
            artikYil = true;
        } else {
            artikYil = false;
        }
        System.out.println("Artik Yıl : "+ artikYil);
        
        /*if ( girdi % 4 == 0) {
            if ( girdi % 100 == 0) {
                if (girdi % 400 == 0) {
                    if ( girdi % 4000 == 0) {
                        artikYil = false;
                    } else {
                        artikYil = true;
                    }
                } else {
                    artikYil = false;
                }
            } else {
                artikYil = true;
            }
        } else {
            artikYil = false;
        }
        System.out.println("Artik Yıl : "+ artikYil);
        */
    }
    
}

        
    


       
    
    

