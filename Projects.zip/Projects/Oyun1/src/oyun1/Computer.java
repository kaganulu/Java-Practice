/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oyun1;

import java.util.Random;

/**
 *
 * @author kaganulu
 */
public class Computer  extends Game{
    private String bilgisayarElSecimi;
    Random r = new Random();
    
    public Computer(){
        
    }
    
    public void bilgisayarEli(){
        int randNumarasi = r.nextInt(3) + 1;
        switch(randNumarasi){
            case 0:
                this.bilgisayarElSecimi = "T";
            case 1:
                this.bilgisayarElSecimi = "K";
            case 2:
                this.bilgisayarElSecimi = "M";
            default:
                System.out.println("HATA!");
        }
    }

    public String getBilgisayarElSecimi() {
        return this.bilgisayarElSecimi;
    }
    public void OyunBaslat(){
        System.out.println("Bilgisayar seçimi: " + getBilgisayarElSecimi());
        
        
    }
        
    }
    

