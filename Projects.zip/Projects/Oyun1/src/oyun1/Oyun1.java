/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oyun1;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Oyun1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Game game = new Game();
        Computer com = new Computer();
        game.OyunBaslat();
        game.oyuncuEli();
        
        
        
    }
    
}
