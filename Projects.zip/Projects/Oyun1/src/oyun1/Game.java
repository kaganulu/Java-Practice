/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oyun1;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Game {
    Scanner scan = new Scanner(System.in);
    private String oyuncuIsmi;
    private String oyuncuElSecimi;
    private boolean oyunuKazanan;
    
    public Game(){
        
    }
    public Game(String oyuncuIsmi){
        this.oyuncuIsmi = oyuncuIsmi;
    }

    public String getOyuncuIsmi() {
        return oyuncuIsmi;
    }
    
    public void oyuncuEli(){
        this.oyuncuElSecimi = scan.nextLine();
        if (oyuncuElSecimi.equalsIgnoreCase("T")){
            System.out.println("Oyuncu Taşı'ı seçti!");
        }else if(oyuncuElSecimi.equalsIgnoreCase("K")){
            System.out.println("Oyuncu Kağıt'ı seçti!");
        }else if(oyuncuElSecimi.equalsIgnoreCase("M")){
            System.out.println("Oyuncu Makas'ı seçti!");
        } else {
            System.out.println("Yanlış bir giriş girmiş olmalısınız!");
        }
    }
    public void OyunBaslat(){
        System.out.println("Hoş Geldiniz: " + getOyuncuIsmi() + "\n Lütfen seçiminizi yapınız!  [T]Taş, [K]Kağıt, [M]Makas" );
        oyuncuEli();
    }
    
}
