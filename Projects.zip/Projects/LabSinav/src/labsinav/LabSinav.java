/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labsinav;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class LabSinav {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // Sezar Alfabe kaydırma 
     /*   Scanner scn = new Scanner(System.in);
        System.out.println("İsminizin haflerini giriniz: ");
        int kaydırmaDegeri = 3;
        char c;
        boolean buyukHarf = false;
        int degiskenDeger;
        while (!scn.hasNextInt())
        {
            System.out.println("Harf giriniz: ");
            c = scn.next().charAt(0);
           // System.out.println("Char : " + c + "numara karşılığı" + (int)c);
            if ((c <= 'z' && c >= 'a') || (c <= 'Z' && c >= 'A')) {
                 if (c <= 'z' && c >= 'a'){
                     buyukHarf = false;
                     
                 } else {
                     buyukHarf = true;
                     
                 }
                 degiskenDeger= c + kaydırmaDegeri;
                 //System.out.println("Char : " + c + "numara karşılığı" + (int)c);
                  if(buyukHarf && degiskenDeger > 'Z'){
                       degiskenDeger = degiskenDeger % ((int) 'Z');
                         degiskenDeger += ((int)'A' - 1);
                  } else if(!buyukHarf && degiskenDeger > 'z'){
                       degiskenDeger = degiskenDeger % ((int) 'z');
                       degiskenDeger += ((int)'a' - 1);
                  }
                
                
                 System.out.println("C için yeni değer : " + (char)degiskenDeger);
            }

        }
      */  
      //  100 ile 1000 arasındaki sayılardan her birinin her bir rakamının basamak sayısı kadar kuvvetini alıp toplamı o sayıya eşit olan kodu yazınız 

      int basamakSayısı;
      int sayi, basamaktakiSayı, basamaktakiSayıKuvveti, toplam;
        for (int i = 100; i < 1000; i++) {
            sayi = i;
            toplam = 0;
            basamaktakiSayı = 0;
            while(sayi > 0) {
                sayi /= 10;
                basamaktakiSayı++;
            }
            sayi =i;
            
            for (int j = 0; j < basamaktakiSayı; j++) {
                basamaktakiSayı = sayi % 10;
                basamaktakiSayıKuvveti = 1;
                for (int k = 0; k < basamaktakiSayı; k++) {
                      basamaktakiSayıKuvveti *= basamaktakiSayı;
                    
                }
                toplam += basamaktakiSayıKuvveti; 
                sayi /=10;
                
            }
            if ( toplam == 1) {
                System.out.println("Armstrong Number : " +i);
            }
            
        }
      
    }

}
