/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proje;

/**
 *
 * @author kaganulu
 */
public interface Telefon {
    String getModel();
    String getBatarya();
    int getEn();
    int getBoy();
    
}
