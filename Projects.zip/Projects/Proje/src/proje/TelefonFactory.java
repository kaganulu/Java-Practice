/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proje;

/**
 *
 * @author kaganulu
 */
public interface TelefonFactory {
    Telefon getTelefon(String model, String batarya, int en, int boy); // Telefon dönmeli
    
    
    
}




/*public static Telefon getTelefon(String model, String batarya, int en, int boy ){ 
// static çüünkü bayiler tel oluşturmasın fabrika da oluşturmasın
 fabrika üzerinden static methodu çalıştıralım
        
        Telefon telefon = null;
        if ("S8".equalsIgnoreCase(model)) {
            telefon = new S8(model,batarya,en,boy); // telefon oluştu
            
        }else if ("Note8".equalsIgnoreCase(model)) {
            telefon = new Note8(model,batarya,en,boy);
            
            
        }else{
            System.out.println("Geçerli bir model değildir!");
        }
        
        
        return telefon;
    }
}*/
