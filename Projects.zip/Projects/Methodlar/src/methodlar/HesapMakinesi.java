/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package methodlar;


public class HesapMakinesi {
    
    public void islemSec(char sembol, int sayi1, int sayi2){
        if (sembol == '*') {
            carp(sayi1, sayi2);
            System.out.println("Çarpma işlemi sonucu : " + carp(sayi1, sayi2));
            
        } else if (sembol == '/') {
            bol(sayi1, sayi2);
            System.out.println("Bölme işlemi sonucu : " + bol(sayi1, sayi2));
        } else if (sembol == '+') {
            topla(sayi1, sayi2);
             System.out.println("Toplamaişlemi sonucu : " + topla(sayi1, sayi2));
        } else if (sembol == '-') {
            cıkar(sayi1, sayi2);
             System.out.println("Çıkarma işlemi sonucu : " + cıkar(sayi1, sayi2));
        }
        
    }
    
    public double topla(int sayi1, int sayi2){
        return sayi1 + sayi2;
    }
    public double cıkar(int sayi1, int sayi2){
        return sayi1 - sayi2;
    }
    public double carp(int sayi1, int sayi2){
        return sayi1 * sayi2;
    }
    public double bol(int sayi1, int sayi2){
        return (double)sayi1 / sayi2;
    }
}
