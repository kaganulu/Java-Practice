/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package methodlar;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Methodlar {
    
    
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Kullanıcıdan 2 sadet sayı ve 1 adet işlem sembolü girdisi isteyin
        // ve sonucu ekrana yazdırın (dört işlem içermesi yeterlidir)
        
        HesapMakinesi hesapMakinesi = new HesapMakinesi();
        Scanner sc = new Scanner(System.in);
        int girdi1, girdi2;
        char islem;
        System.out.println("Kullanıcıdan ilk sayıyı giriniz: ");
        girdi1 = sc.nextInt();
        System.out.println("Kullanıcıdan ikinci sayıyı giriniz: ");
        girdi2 = sc.nextInt();
         System.out.println(" Sembol giriniz: ");
         islem = sc.next().charAt(0);
         hesapMakinesi.islemSec(islem, girdi1, girdi2);
        
        
        
    
        System.out.println(findMax(13, 99));
        int[] sayilar = arrayOlustur(1000, 1295);
        
    }
    
    // 1- access modifier : private, public, protected
    // private sadece aynı sınıf içerisindne erişim sağlar.
    // public proje içerisindeki tüm sınıflardan erişim sağlar.
    // protected paket içerisindeki sınıflardan erişim sağlanır.
    
    // 2- static veya non-static
    
    // 3- return type (geri döndürülecek veri türü)
    
    // 4- metod ismi : camel case findById(Long id)
   
    /**
     * Girilen sayılardan büyük olanı döndürür
     * @param sayi1 Tamsayı
     * @param sayi2 Tamsayı
     * @return Tamsayı olarak büyük olan geri döner 
     */
    
    public static int findMax(int sayi1, int sayi2){
        if (sayi1 > sayi2) {
            return  sayi1;
        } else{
            return  sayi2;
        }
    }
    
    public static int[] arrayOlustur(int baslangic, int bitis){
        int[] yeniArray = new int[bitis - baslangic]; 
        for (int i = 0; i < bitis - baslangic; i++) {
            yeniArray[i] = baslangic + i;
        }
        return yeniArray;
    }
}
