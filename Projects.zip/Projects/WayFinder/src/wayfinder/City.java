package wayfinder;

public class City {
    private String name; // Şehir adı
    private City[] otherCities; // Komşu şehirler
    private int[] travelTimes;  // Mesafeler
    private int neighborCount;  // Toplam komşu sayısı

    public City(String name) {
        this.name = name;
        this.otherCities = new City[50];
        this.travelTimes = new int[50];
        this.neighborCount = 0;
    }

    public String getName() {
        return name;
    }

    // Komşu şehir ekleme
    public void addOtherCities(City city, int time) {
        if (neighborCount < 50) {
            this.otherCities[neighborCount] = city;
            this.travelTimes[neighborCount] = time;
            neighborCount++;
        }
    }

    public City[] getOtherCities() {
        return otherCities;
    }

    public int[] getTimes() {
        return travelTimes;
    }

    public int getOthersCcount() {
        return neighborCount;
    }
}
