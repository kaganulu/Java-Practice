package wayfinder;

public class CountryMap {
    private City[] cities; // Şehirler dizisi
    private int cityCount; // Toplam şehir sayısı

    public CountryMap(int maxCities) {
        this.cities = new City[maxCities];
        this.cityCount = 0;
    }

    // Şehir ekleme
    public void addCity(City city) {
        if (cityCount < cities.length) {
            cities[cityCount] = city;
            cityCount++;
        }
    }

    // İsme göre şehir bulma
    public City getCityByName(String name) {
        for (int i = 0; i < cityCount; i++) {
            if (cities[i].getName().equals(name)) {
                return cities[i];
            }
        }
        return null;
    }

    // Şehir indeksini bulma
    public int getCityIndex(City city) {
        for (int i = 0; i < cityCount; i++) {
            if (cities[i].equals(city)) {
                return i;
            }
        }
        return -1; // Şehir bulunamazsa
    }

    public City[] getCities() {
        return cities;
    }

    public int getCityCount() {
        return cityCount;
    }
}
