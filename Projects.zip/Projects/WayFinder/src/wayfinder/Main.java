package wayfinder;

import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Girdi kontrolü
        if (args.length != 1) {
            System.out.println("Provide the input file name!");
            return;
        }

        try {
            File file = new File(args[0]);
            Scanner scanner = new Scanner(file);

            int cityCount = Integer.parseInt(scanner.nextLine());
            CountryMap map = new CountryMap(cityCount);

            // Şehir ekleme
            String[] cityNames = scanner.nextLine().split(" ");
            for (String name : cityNames) {
                map.addCity(new City(name));
            }

            // Rota ekleme
            int routeCount = Integer.parseInt(scanner.nextLine());
            for (int i = 0; i < routeCount; i++) {
                String[] route = scanner.nextLine().split(" ");
                City c1 = map.getCityByName(route[0]);
                City c2 = map.getCityByName(route[1]);
                int time = Integer.parseInt(route[2]);

                c1.addOtherCities(c2, time);
                c2.addOtherCities(c1, time);
            }

            // En kısa yolu bul
            String[] startEnd = scanner.nextLine().split(" ");
            String result = WayFinder.findShortestPath(map, startEnd[0], startEnd[1]);

            try (PrintWriter writer = new PrintWriter("output.txt")) {
                writer.println(result);
            }

            System.out.println("File read is successful!");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
