package wayfinder;

public class WayFinder {
    public static String findShortestPath(CountryMap map, String startCityName, String endCityName) {
        // Başlangıç ve bitiş şehirlerini haritada bul
        City startCity = map.getCityByName(startCityName);
        City endCity = map.getCityByName(endCityName);

        if (startCity == null || endCity == null) {
            return "Error: Start city or end city does not exist!";
        }

        // Şehir sayısını al
        int cityCount = map.getCityCount();

        // Mesafeleri ve ziyaret durumlarını tutacak diziler
        int[] distances = new int[cityCount];
        boolean[] visited = new boolean[cityCount];

        // Başlangıç şehirden diğer şehirlere olan yolları başlat
        for (int i = 0; i < cityCount; i++) {
            distances[i] = Integer.MAX_VALUE; // Başlangıçta tüm mesafeler sonsuz
            visited[i] = false;               // Tüm şehirler başta ziyaret edilmemiş
        }

        // Başlangıç şehrinin indeksini al ve mesafeyi 0 yap
        int startIndex = map.getCityIndex(startCity);
        distances[startIndex] = 0;

        // Şehirler arasında kısa yolları bulmak için döngü
        for (int i = 0; i < cityCount; i++) {
            // Ziyaret edilmemiş en yakın şehri bul
            int currentCityIndex = getMinDistanceIndex(distances, visited, cityCount);

            if (currentCityIndex == -1) {
                break; // Ziyaret edilecek şehir kalmadıysa çık
            }

            // Şehir ziyaret edildi olarak işaretle
            visited[currentCityIndex] = true;

            // Komşu şehirlerin mesafelerini güncelle
            City currentCity = map.getCities()[currentCityIndex];
            City[] neighbors = currentCity.getOtherCities();
            int[] travelTimes = currentCity.getTimes();

            for (int j = 0; j < currentCity.getOthersCcount(); j++) {
                City neighborCity = neighbors[j];
                int neighborIndex = map.getCityIndex(neighborCity);

                if (!visited[neighborIndex]) {
                    int newDistance = distances[currentCityIndex] + travelTimes[j];
                    if (newDistance < distances[neighborIndex]) {
                        distances[neighborIndex] = newDistance;
                    }
                }
            }
        }

        // Bitiş şehrinin indeksini al ve sonucu döndür
        int endIndex = map.getCityIndex(endCity);
        if (distances[endIndex] == Integer.MAX_VALUE) {
            return "No way exists between " + startCityName + " and " + endCityName;
        } else {
            return "Fastest way from " + startCityName + " to " + endCityName +
                   " takes " + distances[endIndex] + " minutes.";
        }
    }

    // En kısa mesafeyi bulmak için yardımcı metod
    private static int getMinDistanceIndex(int[] distances, boolean[] visited, int cityCount) {
        int minIndex = -1;
        int minDistance = Integer.MAX_VALUE;

        for (int i = 0; i < cityCount; i++) {
            if (!visited[i] && distances[i] < minDistance) {
                minDistance = distances[i];
                minIndex = i;
            }
        }
        return minIndex;
    }
}
