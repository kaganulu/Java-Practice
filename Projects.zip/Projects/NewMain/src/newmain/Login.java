/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newmain;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Login {
    public boolean Login(Hesap hesap){
        
        Scanner scan = new Scanner(System.in);
        String kullanici_adi;
        String parola;
        
        System.out.println("Kullanıcı adınız: ");
        kullanici_adi = scan.nextLine();
        System.out.println("Parolanızı giriniz: ");
        parola = scan.nextLine();
        
        if (hesap.getKullanici_adi().equals(kullanici_adi) && hesap.getParola().equals(parola)) {
            return true;
            
        } else{
            return false;
        }
    }
}
