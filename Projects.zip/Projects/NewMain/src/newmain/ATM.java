/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newmain;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class ATM {
    public void calis(Hesap hesap){
    Login login = new Login();
    
    Scanner input = new Scanner(System.in);
    
    System.out.println("Bankamıza Hoşgeldiniz!");
    
    String islemler = "1. Bakiye Görüntüle\n"
                        + "2. Para Yatırma\n"
                        + "3. Para Çekme\n"
                        + "Çıkış için x'e basın";
        System.out.println(islemler);
                      
       while (true) {
            System.out.println("İşlem Seçiniz:");
            String islem = input.nextLine();
            
            if (islem.equals("x")) {
                
                break;
                
            }
            else if (islem.equals("1")) {
                System.out.println("Bakiyeniz: " + hesap.getBakiye());
                
            }
            else if (islem.equals("2")) {
                
                System.out.print("Yatırmak İstediğiniz Tutarı Giriniz: ");
                int tutar = input.nextInt();
                input.nextLine();
                hesap.ParaYatir(tutar);
            }
            else if (islem.equals("3")) {
                      
                System.out.print("Çekmek İstediğiniz Tutarı Giriniz:");
                
                
                int tutar = input.nextInt();
                input.nextLine();
                hesap.ParaCekme(tutar);

            }
            else{
                System.out.println("Geçersiz İşlem");
            }
       }
     
    
    }
       
    
}
