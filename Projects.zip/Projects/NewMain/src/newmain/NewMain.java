/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newmain;

/**
 *
 * @author kaganulu
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ATM atm = new ATM();
        Hesap hesap = new Hesap("Kağan" ,"1234" , 10000);
        atm.calis(hesap);
        System.out.println("Programdan Çıkılıyor Güle Güle...");
    }
    
}
