/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labsınav2;

import java.util.Random;

/**
 *
 * @author kaganulu
 */
public class LabSınav2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     
      //  Rastgele oluşturulan 0-9 (dahil) arasındaki rakamlardan oluşan 
      //  10000 elemanlı dizide artan yönde ardışık olarak bulunan en 
       // uzun ilk alt dizinin uzunluğu kaçtır? (temel veri tipleri, 
      //  döngüler, koşullar, diziler ve Random sÄayılar kullanılacaktır)
     //   Örnek dizi=[...5,8,2,1,2,3,4,9,0,...,4,5,6,7,8,9,1,2,5,2,3,.....]
      //  ArdisikDizi1= [1,2,3,4], ArdisikDizi2=[4,5,6,7,8,9], ArdısikDizi3=[1,2] 
       // cevap = ardisik dizi 2 uzunlugu 6
       
       Random r = new Random(0);
       int[] sayilar = new int[10000];
       int maxUzunluk = Integer.MIN_VALUE, maxUzunlukIndex = Integer.MIN_VALUE;
       int suankiUzunluk = Integer.MIN_VALUE, suankiUzunlukIndex;
        for (int i = 0; i < sayilar.length; i++) {
            sayilar[i] = r.nextInt(10);
        }
       System.out.println("Dizi oluşturuldu.");
        for (int i = 0; i < sayilar.length; i++) {
            suankiUzunluk = 1;
            suankiUzunlukIndex = i;
            for (int j = i + 1; j < sayilar.length; j++) {
                if (sayilar[i] + suankiUzunluk == sayilar[j]) {
                    suankiUzunluk++;
                    
                } else{
                    break;
                }
                
            }
            if (suankiUzunluk > maxUzunluk) {
                maxUzunluk = suankiUzunluk;
                maxUzunlukIndex = suankiUzunlukIndex;
                
            }
        }
        if (maxUzunlukIndex < 0) {
            System.out.println("Ardışık seri bulunamadı. ");
            
        } else{
            for (int i = 0; i < maxUzunluk; i++) {
                System.out.printf("%d", sayilar[maxUzunlukIndex + i]);
            }
            System.out.printf(" Max başlangıç indexi = %d, uzunluk %d", maxUzunlukIndex,maxUzunluk);
        }
    }
}