/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calisma;

/**
 *
 * @author kaganulu
 */
public class Calisma {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Product product = new Product(1,"Laptop","Apple Macbook", 10000,2,"Siyah");
       
        
        ProductManager productManager = new ProductManager();
        productManager.Add(product);
        
        System.out.println(product.getKod());
    }
    
}
