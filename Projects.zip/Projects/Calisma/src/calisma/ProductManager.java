/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calisma;

/**
 *
 * @author kaganulu
 */
public class ProductManager {
    public  void Add(Product product){
        System.out.println("Ürün eklendi "+product.getName());
    }
    public void Add(int id,String name,String description,int stockAmount,double price){
        
    }
    
}
