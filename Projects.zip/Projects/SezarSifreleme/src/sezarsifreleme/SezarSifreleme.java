/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sezarsifreleme;

/**
 *
 * @author kaganulu
 */
public class SezarSifreleme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          /*
        Kullanıcının girdiği metini Sezar şifreleme yöntemini
        kullanarak şifreleyen bir metot ve daha
        sonra istenirse bu şifreyi çözen bir metot içeren
        Sezar isimli bir sınıf oluşturunuz.
        (ipucu : --- (char)(s.charAt(i)+3) ---)
        */
        String k = sezar.codesezar("!!! Merhaba bugün güzel bir gün !!!");
        System.out.println(k);
        
        String d = sezar.decodeSezar(k);
        System.out.println(d);

        
    }
}
