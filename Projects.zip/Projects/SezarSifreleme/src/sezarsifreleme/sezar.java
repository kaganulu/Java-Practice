/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sezarsifreleme;

/**
 *
 * @author kaganulu
 */
public class sezar {
     public static String codesezar(String s){
        // Şifrelenmiş Yazı Buraya Yazılı
        String coded = "";

        // Kelimedeki karakter sayısı kadar
        // For döngüsüne sokulur
        for (int i = 0; i < s.length(); i++) {
            // Döngü ile ilgili str'in i'inci karakteri alınır
            char c = s.charAt(i);

            if(
              (c <= 122 && c >= 97) ||
              (c <= 90 && c >= 65)
            ) {
                // Karakter değerleri arasında
                coded += (char) (c + 3);
            }  else {
                // Diğerlerini Şifreleme
                coded += c;
            }

        }

        return coded;
    }

    public static String decodeSezar(String s){
        // Şifrelenmiş Yazı Buraya Yazılı
        String coded = "";

        // Kelimedeki karakter sayısı kadar
        // For döngüsüne sokulur
        for (int i = 0; i < s.length(); i++) {
            // Döngü ile ilgili str'in i'inci karakteri alınır
            char c = s.charAt(i);

            if(
              (c <= 122 && c >= 97) ||
              (c <= 90 && c >= 65)
            ) {
                // Karakter değerleri arasında
                coded += (char) (c - 3);
            }  else {
                // Diğerlerini Şifreleme
                coded += c;
            }

        }

        return coded;
    }
    
    }

