/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vizecallismasorusu;

import java.util.Random;

/**
 *
 * @author kaganulu
 */
public class VizeCallismaSorusu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        //Random 17 elemanli 0-100 arasında rakamlardan olusan
        //bir dizi oluşturun. Ortadaki 5 eleman
        //0 ile 5 arasinda olsun
        /*  Random r = new Random(0);
        int[] sayilar = new int[17];
        
        for (int i = 0; i < sayilar.length; i++) {

        sayilar[i] = r.nextInt(101);

        }

        int baslangıc = (17 - 5 ) /2;

        for (int i = 0; i < 5; i++) {

          if ( !(sayilar[baslangıc + i] <= 5 && sayilar[baslangıc +i] >= 0) ) {

            sayilar[baslangıc + i] = r.nextInt(6);

          }

        }

       
        
        for (int i = 0; i < sayilar.length; i++) {
           System.out.print(sayilar[i] + " ");
        }

    /*
    int baslangıc = (17 - 5 ) /2;

    for (int i = 0; i < baslangıc; i++) {

      sayilar[i] = r.nextInt(101);

      System.out.print(sayilar[i] + " ");

    }

    for (int i = baslangıc; i < baslangıc + 5; i++) {

      sayilar[i] = r.nextInt(6);

      System.out.print(sayilar[i] + " ");

    }

    for (int i = 17-1; i >= baslangıc + 5; i--) {

      sayilar[i] = r.nextInt(101);

      System.out.print(sayilar[i] + " ");

    }
       
        // 2 zar aynı anda atılsın.
        //   zarların toplamı 5 veya 12 ise KAZANDINIZ mesajı verilsin.
        //   Kişinin 10 deneme hakkı olsun. NOT: bu koşul if ile halledilsin.
        Random r = new Random();
        int zarAtmaHakki = 10;
        int atilanZar = 0;
        int zar1, zar2, zarToplam;
        while (true) {
            zar1 = r.nextInt(6) + 1;
            zar2 = r.nextInt(6) + 1;
            zarToplam = zar1 + zar2;
            atilanZar++;
            if (zarToplam >= 5 && zarToplam <= 12) {
                System.out.printf("Kazandınız :) Zarlar: %d-%d atılan zar = %d\n", zar1, zar2, atilanZar);
                break;
            }
            if (atilanZar == zarAtmaHakki) {
                System.out.println("Kaybettiniz :(");
                break;
            }

        }
          */
        
          // Random sinifi ile 0-9 (dahil) 100 tane tam sayi oluÅŸturun. 
        // Diziye bu değerleri doldurun.
        // Her bir sayidan kac tane oldugunu ekrana yazdÄ±rÄ±n.
        // Aynı sayiları tekrar yazdırmayacak.
        
        
        Random r = new Random(0);
        int[] sayilar = new int[100];
        for (int i = 0; i < sayilar.length; i++) {
            sayilar[i] = r.nextInt(10);
        }
        int[] adetliSayilar = new int[10];
        for (int i = 0; i < sayilar.length; i++) {
            adetliSayilar[sayilar[i]] = adetliSayilar[sayilar[i]]+1;
        }
        for (int i = 0; i < adetliSayilar.length; i++) {
            System.out.printf("%d sayisindan %d adet vardir.\n", i, adetliSayilar[i] );
        }
        
        
        
        
    }
}
