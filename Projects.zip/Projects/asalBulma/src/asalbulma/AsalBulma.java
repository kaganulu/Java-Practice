/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asalbulma;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class AsalBulma {

    /**
     * @param args the command line arguments
     */
    
    private static void asal(int x){
        int k = 0;
        for (int i = 2; i < x; i++) {
            if (x % i == 0) {
                k++;
                break;
            }
            
        }
        if (k==0) System.out.println("Sayı asal");
        else System.out.println("Sayı asal değil!");
 
            
     }
    
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
        System.out.println("Hangi sayının asal olup olmadığını kontrol etmek istiyorsunuz? :");
       asal(sc.nextInt());
        
        
    }
    
}
