/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainvize;

import java.util.Random;

/**
 *
 * @author kaganulu
 */
public class PC extends Dovusen implements IEylem{

    Random r = new Random();
    
    public PC(String ad){
        super(ad);
    }
    
    @Override
    public int dovus() {
        if (r.nextInt(100)<60) {
            int hasar = r.nextInt(11)+5;
            System.out.println(this.getIsim()+" "+hasar+" hasar verdi.");
            return hasar;
            
        }
        else{
            System.out.println(this.getIsim()+" savunma yapti. Hasar gecersiz.");
            return -1; 
        }
    
    }
    
}
