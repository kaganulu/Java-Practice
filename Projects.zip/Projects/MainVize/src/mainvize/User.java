/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainvize;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class User extends Dovusen implements IEylem {

    Scanner sc = new Scanner(System.in);
    Random r = new Random();

    public User(String ad) {
        super(ad);
    }

    @Override
    public int dovus() {
        String menu = "Lutfen hamle seciniz\n1 - Saldiri\n2 - Savunma";
        System.out.println(menu);
        int tercih = sc.nextInt();

        if (tercih == 1) {
            int hasar = r.nextInt(11) + 5;
            System.out.println(this.getIsim() + " " + hasar + " hasar verdi.");
            return hasar;
        } else {
            System.out.println(this.getIsim() + " savunma yapti. Hasar gecersiz.");
            return -1;
        }
    }

}


