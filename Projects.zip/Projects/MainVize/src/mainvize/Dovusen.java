/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainvize;

/**
 *
 * @author kaganulu
 */
public abstract class Dovusen {

    protected int HP;
    protected String isim;

    protected Dovusen(String ad) {
        this.HP = 100;
        this.isim = ad;
    }

    public void hasarAl(int hasar) {
        this.HP -= hasar;
    }

    public int getHP() {
        return this.HP;
    }

    public String getIsim() {
        return this.isim;
    }
    
    

}
