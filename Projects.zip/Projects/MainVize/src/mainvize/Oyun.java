/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainvize;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Oyun  {

    PC p;
    User u;

    Scanner scan = new Scanner(System.in);

    public Oyun() {
        System.out.println("Pc için isim giriniz:  ");
        String ad = scan.nextLine();
        this.p = new PC(ad);

        System.out.println("Kullanici icin isim giriniz");
        ad = scan.nextLine();
        this.u = new User(ad);
    }

    public void baslat() {
        while (p.getHP() > 0 && u.getHP() > 0) {
            System.out.println(u.getIsim() + " HP : " + u.getHP());
            System.out.println(p.getIsim() + " HP : " + p.getHP());
            int ud = u.dovus();
            int pd = p.dovus();
            if (ud != -1 && pd != -1) {
                p.hasarAl(ud);
                u.hasarAl(pd);
            }
        }
        if (p.getHP() <= 0 && u.getHP() <= 0) {
            System.out.println("Berabere kaldilar");
        } else if (p.getHP() > 0) {
            System.out.println(p.getIsim() + " kazandi");
        } else {
            System.out.println(u.getIsim() + " kazandi");
        }

    }
}

