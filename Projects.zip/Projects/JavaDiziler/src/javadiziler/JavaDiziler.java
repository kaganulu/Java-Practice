/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javadiziler;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class JavaDiziler {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        /* 1-Klavyeden 1 sayi giriniz
      2-Bu uzunlukta rastgele değerlerden olusan bir dizi yaratın
      3-Olusan bu listeyi büyükten küçüğe sıralı hale getirin.
         */
 /*
        Scanner sc = new Scanner(System.in);
        System.out.println("Liste uzunluğunu giriniz");
        int listeUzunluğu = sc.nextInt();
        int[] sayilar = new int[listeUzunluğu];
        
        Random r = new Random(0);
        for (int i = 0; i < sayilar.length; i++) {
            sayilar[i] = r.nextInt(); // r yerine sc yazarsak kullanıcı rakamları yazar. 
            
        }
        System.out.println("Dizi oluşturuldu");
        int temp;
        int max;                
        int maxIndex = 0;   
        boolean güncellendi = false;  
        for (int i = 0; i < sayilar.length - 1; i++) {
            max = Integer.MIN_VALUE; // max  değeri en küçük ınteger değerine eşittir. Çünkü her sayı benim en küçük sayı değerinden büyük veya eşit olacağıiçin sayıyı günceller.
            güncellendi = false;
            
            for (int j = i + 1; j < sayilar.length; j++) { // i değerinden sonrakilerde i den küçük değer var mı diye bakıyoruz.
                if (sayilar[i] < sayilar[j] && sayilar[j] > max) {    // içindeki değeri max da tutuyoruz. max index te index numarası tutuyoruz.
                    max = sayilar[j];
                    maxIndex = j;  
                    güncellendi = true;
                    
                }
    
                
            }
            if (güncellendi) {
                temp = sayilar[i];
                sayilar[i] = sayilar[maxIndex];
                sayilar[maxIndex] = temp;
            }
            
        }
        for (int i = 0; i < sayilar.length; i++) {
            System.out.printf("Sayilar[%d] = %4d \n", i, sayilar[i]);
            
        }
         */
        // 20 elemanlı 10 pozitif 10 negatif rastgele sayıdan oluşsan bir dizi yaratınız.
        // Bu dizide sıralama her bir negatif tam sayidan sonra pozitif bir tam sayi gelecek şekilde ve negatif sayilar artarak
        //pozitif sayılarda azalacak şekilde sıralayınız.
        // Örnek : dizi[1,-88, -741,12,-6,565,2,5,-22,-35] 
        // rastgele oluşturulan 5pozitif+5nefatif = 10 elemanlı dizinin
        //siralama sonucu sıralıDizi=[-742, 565, -88, 12, -35, 5, -22, 5, -6, 1] şeklinde olacaktır.
        
        Random r = new Random(0);
        int toplamSayi = 0, pozitifSayi = 0, negatifSayi = 0;
        int[] sayilar = new int[20];
        int olusturulanSayi;

        while (toplamSayi < 20) {
            olusturulanSayi = r.nextInt(21) - 10; // -10 ile +10 arasında oluşturalım dedik
            if (olusturulanSayi < 0 && negatifSayi < 10) {
                negatifSayi++;
                sayilar[toplamSayi] = olusturulanSayi;
                toplamSayi++;

            } else if (olusturulanSayi >= 0 && pozitifSayi < 10) {
                pozitifSayi++;
                sayilar[toplamSayi] = olusturulanSayi;
                toplamSayi++;

            }
        }
         System.out.println("Oluşan liste");
        for (int i = 0; i < sayilar.length; i++) {
            System.out.print(sayilar[i] + " ");
        }
        System.out.println("");
        int min;
        int minIndex;
        for (int i = 0; i < sayilar.length - 1; i++) {
            min = sayilar[i];
            minIndex = i;
            for (int j = i + 1; j < sayilar.length; j++) {
                if (sayilar[j] < sayilar[i] && sayilar[j] < min) {
                    min = sayilar[j];
                    minIndex = j;
                }
            }
            
            if (i != minIndex) {
                for (int j = minIndex; j > i; j--) {
                    sayilar[j] = sayilar[j - 1];
                }
                sayilar[i] = min;
            }
        }
        System.out.println("\n Sıralı liste");
        for (int i = 0; i < sayilar.length; i++) {
            System.out.print(sayilar[i] + " ");
        }
        
        
        int pozitifBaslangici=0;
        for (int i = 0; i < sayilar.length; i++) {
            if ( sayilar[i] >= 0) {
                pozitifBaslangici = i;
                break;
            }
        }
        
        int[] pozitifListesi = new int[sayilar.length - pozitifBaslangici];
        for (int i = 0; i < pozitifListesi.length; i++) {
            pozitifListesi[i] = sayilar[(sayilar.length-1)-i];
        }
        int[] kosulSiraliListe = new int[20];
        for (int i = 0; i < 10; i++) {
            kosulSiraliListe[2*i] = sayilar[i];
            kosulSiraliListe[2*i+1] = pozitifListesi[i];
        }
        
        System.out.println(" \n Koşul sıralı liste ");
        for (int i = 0; i < kosulSiraliListe.length; i++) {
            System.out.printf("%d ",kosulSiraliListe[i]);
            
        }
        
        
        
        
       // System.out.println("\n Kurallara uygun liste ");
       // for (int i = 0; i < sayilar.length/2; i++) {
        //    System.out.printf("%d %d", sayilar[i], sayilar[(sayilar.length-1)-i] );
            
       // }
    }
}

//                 minIndex = 8
//                                         min
//                       i
// [-742, 565, -88, 12,  5 , -22, 5, -6,  -35, 1]
//                                               j

