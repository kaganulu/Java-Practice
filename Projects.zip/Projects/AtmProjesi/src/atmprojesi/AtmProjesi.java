/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmprojesi;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class AtmProjesi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int bakiye = 2000, imput, miktar;
        Scanner scan = new Scanner(System.in);

        System.out.println("Merhabalar Kağan banka hoşgeldiniz. ");
        System.out.println("Güncel bakiyeniz: " + bakiye + "TL");

        while (bakiye > 0) {
            System.out.println();
            System.out.println("1-)Para Yatır");
            System.out.println("2-)Para Çek");
            System.out.println("3-)Bakiye Sorgula");
            System.out.println("4-)Çıkış");
            System.out.println("Lütfen yapmak istediğiniz işlemi seçiniz: ");
            imput = scan.nextInt();

            if (imput == 1) {
                System.out.println("Yatırmak istediğiniz miktarı giriniz: ");
                miktar = scan.nextInt();
                bakiye += miktar;

            } else if (imput == 2) {
                System.out.println("Çekmek istediğiniz miktar: ");
                miktar = scan.nextInt();

                if (miktar > bakiye) {
                    System.out.println("Yetersiz bakiye!!");
                } else {
                    bakiye -= miktar;
                }

            } else if (imput == 3) {
                System.out.println("Güncel bakiyeniz: " + bakiye + "TL");

            } else if (imput == 4) {
                System.out.println("Çıkış yapılıyor!!");
                break;

            } else {
                System.out.println("Geçersiz bir işlem girdiniz !");
            }
        }

    }

}
