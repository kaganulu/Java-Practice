/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ornek;

/**
 *
 * @author kaganulu
 */
public class Game {
    Cpu c = new Cpu();
    User u = new User();
    public void baslat(){
        int ct = c.oyna(); // Cpu tercih
        int ut = u.oyna(); // User tercih
        
        if (ct == ut) {
            System.out.println("Beraberlik");
        }else if(ut == 1 && ct == 3) {
            System.out.println("Kullanıcı kazandı.");
        }else if (ut == 2 && ct == 1) {
             System.out.println("Kullanıcı kazandı.");
        }else if (ut == 3 && ct == 2) {
             System.out.println("Kullanıcı kazandı.");
        }else{
             System.out.println("Kullanıcı kaybetti!");
        }
        
    }
    
}
