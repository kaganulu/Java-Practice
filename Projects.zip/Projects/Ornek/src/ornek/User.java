/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ornek;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class User {
    Scanner scan = new Scanner(System.in);
    public int oyna(){
        System.out.println("1 - Taş");
        System.out.println("2 - Kağıt");
        System.out.println("3 - Makas");
        System.out.println("Hangisini seçmek istiyorsun? :");
        int tercih = scan.nextInt();
        System.out.println("Kullanıcı tercihi : "+tercih);
        return tercih;
    }
}
