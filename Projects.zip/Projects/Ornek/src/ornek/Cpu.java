/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ornek;

import java.util.Random;

/**
 *
 * @author kaganulu
 */
public class Cpu {
    Random r = new Random();
    
    public int oyna(){
        int tercih = 1 + r.nextInt(3);
        System.out.println("Cpu tercihi : " +tercih);
        return tercih;
    }
}
