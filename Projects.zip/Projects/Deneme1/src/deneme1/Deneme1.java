/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deneme1;

/**
 *
 * @author kaganulu
 */
public class Deneme1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int x = 10;
        int y;
        int kagan;
        kagan = 10;
        System.out.println("Merhaba Dünya"+ kagan);
        kagan = 20;
        System.out.println("Merhaba Dünya"+ kagan);
        double pi = 3.14;
        String s = "benim ismim kağan ulu";
        System.out.println(" 10. karakter : "+ s.charAt(10) );
        s = s.toUpperCase();
        int ilkBosluk = s.indexOf(" ");
        String ilkKelime = s.substring(0, ilkBosluk);
        int sonBosluk = s.lastIndexOf(" ");
        String sonKelime = s.substring(sonBosluk);
        System.out.println(" dizgi " +  s + " pi: " + pi + "ilk bosluk : "+ ilkBosluk);
        System.out.println(" ilk kelime değişkeni" + ilkKelime);
        System.out.println(" son kelime : " + sonKelime);
        
        
    }
    
}
