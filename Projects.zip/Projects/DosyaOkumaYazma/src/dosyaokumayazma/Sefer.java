/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dosyaokumayazma;

/**
 *
 * @author kaganulu
 */
public class Sefer {
    
    private String seferTipi;
    private int seferSaati;
    private int seferDakikasi;
    
    public Sefer(String seferTipi, int seferSaati, int seferDakikasi){
        this.seferTipi = seferTipi;
        this.seferSaati = seferSaati;
        this.seferDakikasi = seferDakikasi;
    }
    
    public Sefer(){
        
    }

    public String getSeferTipi() {
        return seferTipi;
    }

    public void setSeferTipi(String seferTipi) {
        this.seferTipi = seferTipi;
    }

    public int getSeferSaati() {
        return seferSaati;
    }

    public void setSeferSaati(int seferSaati) {
        this.seferSaati = seferSaati;
    }

    public int getSeferDakikasi() {
        return seferDakikasi;
    }

    public void setSeferDakikasi(int seferDakikasi) {
        this.seferDakikasi = seferDakikasi;
    }
    
    
}
