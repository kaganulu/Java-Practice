/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dosyaokumayazma;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DosyaOkumaYazma {

    public static void main(String[] args) {
      //int[][] sayilar = new int[3][6];
        int[][] sayilar = {{1, 2, 3, 4, 5, 6}, {7, 8, 9, 10, 11, 12}, {13, 14, 15, 16, 17, 18}};
        sayilariDosyayaYaz("sayilar.txt", sayilar);

        Sefer[] seferler = seferleriDosyadanOku("seferler.txt");
        
        for (int i = 0; i < seferler.length; i++) {
            System.out.printf("%s\t%2d:%2d\n", seferler[i].getSeferTipi(),seferler[i].getSeferSaati(),seferler[i].getSeferDakikasi());
        }
    }
    
    public static Sefer[] seferleriDosyadanOku(String seferDosyasiAdi){
        Sefer[] okunanSeferler = new Sefer[0];
        
        File dosya = new File(seferDosyasiAdi);
        try {
            FileReader dosyaOkuyucusu = new FileReader(dosya);
            BufferedReader tamponluOkuyucu = new BufferedReader(dosyaOkuyucusu);
            int seferSayisi = Integer.valueOf(tamponluOkuyucu.readLine()); //"5" => 5
            okunanSeferler = new Sefer[seferSayisi];
            
            for (int i = 0; i < okunanSeferler.length; i++) {
                String satir = tamponluOkuyucu.readLine(); // Tren seferi,13,20
                String[] satirIcerikleri = satir.split(","); //{"Tren seferi", "13", "20"}
                Sefer yeniSefer = new Sefer();
                yeniSefer.setSeferTipi(satirIcerikleri[0]);
                yeniSefer.setSeferSaati(Integer.valueOf(satirIcerikleri[1]));
                yeniSefer.setSeferDakikasi(Integer.valueOf(satirIcerikleri[2]));
                okunanSeferler[i] = yeniSefer;
            }
            tamponluOkuyucu.close();
            dosyaOkuyucusu.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DosyaOkumaYazma.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DosyaOkumaYazma.class.getName()).log(Level.SEVERE, null, ex);
        }
        return okunanSeferler;
    }
    
    

    public static void sayilariDosyayaYaz(String dosyaAdi, int[][] sayilar) {
        int birinciParametre = 0;
        int ikinciParametre = 0;
        if (sayilar != null) {
            birinciParametre = sayilar.length;
            if (sayilar[0] != null) {
                ikinciParametre = sayilar[0].length;
            }
        }
        if (birinciParametre != 0 && ikinciParametre != 0) {
            File dosya = new File(dosyaAdi);

            try {
                if (!dosya.exists()) {
                    dosya.createNewFile();
                }
                FileWriter dosyaYazici = new FileWriter(dosya);
                BufferedWriter tamponluYazici = new BufferedWriter(dosyaYazici);
                tamponluYazici.write(birinciParametre + "," + ikinciParametre+"\n");
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < sayilar.length; i++) {
                    for (int j = 0; j < sayilar[i].length; j++) {
                        sb.append(sayilar[i][j]);
                        if ( j < sayilar[i].length - 1) {
                            sb.append(",");
                        }
                    }
                    if ( i < sayilar.length - 1) {
                        sb.append("\n");
                    }
                }
                tamponluYazici.write(sb.toString());
                tamponluYazici.close();
                dosyaYazici.close();
            } catch (IOException ex) {
                Logger.getLogger(DosyaOkumaYazma.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    /*public static int[][] dosyaOku(String dosyaAdi) {

    }*/
}
