/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg100metrelikyaris;

import java.util.Random;

/**
 *
 * @author kaganulu
 */
public class Tavsan extends Hayvan {

    Random r = new Random();

    public void kos() {
        int zar = r.nextInt(6);

        if (zar == 0 || zar == 1 || zar == 2) {
            konum = konum + 2;
        } else if (zar == 3) {
            System.out.println("Tavşan Yemekte!");
        } else if (zar == 4 || zar == 5) {
            konum--;
        }
    }
}
