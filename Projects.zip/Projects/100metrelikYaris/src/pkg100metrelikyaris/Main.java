/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg100metrelikyaris;

/**
 *
 * @author kaganulu
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Tavsan t = new Tavsan();
        Kaplumbaga kap = new Kaplumbaga();
        
        while(t.getKonum()<100 && kap.getKonum()<100){
            t.kos();
            kap.kos();
        }
        if (t.getKonum() == 100 && kap.getKonum() == 100) {
            System.out.println("Berabere Kaldılar");
        }else if (t.getKonum()>=100) {
            System.out.println(" Tavşan Kazandı");
        }else if (kap.getKonum()>=100) {
             System.out.println(" Kaplumbağa Kazandı");
        }
    }
    
}
