/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haftaıkisorular;

/**
 *
 * @author kaganulu
 */
public class HaftaIkiSorular {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        /** 46711 sayısının 41 e bölümü ve kalanı kaçtır?*/
        System.out.println("46711 in 41 e bölümünden kalan = " + ( 46711 % 41));
        System.out.println("46711 in 41 e bölümü = " +  (46711 / 41));
        System.out.println("46711 in 41 e bölümü = " +  (46711.0 / 41));
        
        
        /** A ve B şehirlerinin mesafesi 300 kilometredir. A şehrinden saatte 50 km ile B
şehrine, B şehrinden saatte 30 km/h ile A şehrine doğru ilerleyen araçlardan; A
şehrinden yola çıkan araç B şehrine vardıktan kaç saat sonra B şehrinden kalkan araç A
şehrine varmış olur?*/
        
        int mesafe = 300;
        int hizA = 50;
        int hizB = 30;
        
        double seyahatSuresiA = mesafe / hizA;
        double seyahatSuresiB = mesafe / hizB;
        
        double sureFarki = seyahatSuresiB - seyahatSuresiA ;
        System.out.println("B aracı A aracından sonra  " + sureFarki + " saat daha yolculuk etmiştir. ");
        
    }
    
}
