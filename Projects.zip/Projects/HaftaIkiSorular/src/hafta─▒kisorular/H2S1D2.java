/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haftaıkisorular;

import java.util.Scanner;
/**
 *
 * @author kaganulu
 */
public class H2S1D2 {
    public static void main(String[] args) {
    
    // 1100 1011 8 bit => 1 byte Mbps
    // 1111 1111 0 - ( 2^8 - 1) 0-256  | -128 (1111 1111) -> +127 (0111 1111) | (0000 0000) = 0
    // byte -128 +127 arasındaki 256 farklı kombinasyonu kullanabilyoruz.
    System.out.println("Kağan dedi ki; \" kodu kontrol et \". \n \' \t 2 \\ 3");
    
    //          VE &&                           VEYA ||
        /*            true    false                      true    false
               true   true    false            true     true    true                  
              false   false   false           false     true    false
        */
        
        boolean A = true;
        boolean B = false;
        
        System.out.println("A ve B : " + ( A && B) + " - A veya B : " + (A || B));
        
        //ternary 
        int alininYaşı = 17;
        int ayşeninYaşı = 16;
        
        boolean sonuc = (alininYaşı > ayşeninYaşı) ? true : false;
        System.out.println("Ali Ayşeden büyüktür : " + sonuc);
        
         //Bit bazında işlemler   0000 -> 0
        /*
            0001 -> 1
            0010 -> 2
        
            1011 -> (2^0) * 1 + (2^1) * 1 + (2^2) * 0 + (2^3) * 1 = 1+2+0+8 => 11
        */
        
        int s1 = 15;
        int s2 = 3;
        System.out.println("A = " + s1 + " B = " + s2);
        s1-=s2;
        //s1 = s1 - s2;
        System.out.println("A = " + s1 + " B = " + s2);
        
        Scanner input = new Scanner(System.in);
        System.out.println("Kaç yaşındasın ?");
        int yaş = input.nextInt();
        System.out.println(yaş + " güzel bir yaş!");
        
        System.out.println("Bir metin girin.");
        String metin = input.next();
        System.out.println("Girilen metin = " + metin);
}
}