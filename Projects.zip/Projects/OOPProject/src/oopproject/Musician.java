/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopproject;

/**
 *
 * @author kaganulu
 */
public class Musician {
    private String name;
    private String instrument;
    private int age;
    
    public Musician(String name, String instrument, int age){
        this.name=name;
        this.instrument=instrument;
        this.age=age;
        
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setInstrument(String instrument) {
        this.instrument = instrument;
    }

    public void setAge(int age, String password) {
        if (password.matches("Kağan")){
            this.age = age;
        }
    }
    
    

    public String getName() {
        return name;
    }

    public String getInstrument() {
        return instrument;
    }

    public int getAge() {
        return age;
    }
    
    
}
