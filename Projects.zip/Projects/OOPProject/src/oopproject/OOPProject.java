/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopproject;

/**
 *
 * @author kaganulu
 */
public class OOPProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       /* 
        User myUser = new User();
        myUser.name = "Kağan";
        myUser.job = "Software Engineer";
        */
       
      /*   User myUser = new User("Kağan","Software Engineer");
        
       System.out.println(myUser.name);
                
       // Encapsulation
       Musician james = new Musician("James","Guitar",50);
       james.setAge(60,"Kağan");
       System.out.println(james.getAge());
       System.out.println(james.getName());
       
        */
       // Inheritance 
       SuperMusician lars = new SuperMusician("Lars", "Drums", 55);
        System.out.println(lars.sing());
        System.out.println(lars.getAge());
        
        
      // Polymorphism
      // Static Polymorphism
      
      Mathematics mathematics = new Mathematics();
      System.out.println(mathematics.sum());
      System.out.println(mathematics.sum(5,3));
      System.out.println(mathematics.sum(5,3,4));
      
      
       // Dinamic Polymorphism
      Animal myAnimal = new Animal();
      myAnimal.sing();
      
      Dog barley = new Dog();
      barley.test();
      barley.sing();
       
      
      Piano myPiano = new Piano();
      myPiano.brand = "Yamaha";
      myPiano.digital = true;
      myPiano.info();
      
    }
    
}
