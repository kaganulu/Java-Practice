/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopproject;

/**
 *
 * @author kaganulu
 */
public class SuperMusician extends Musician {

    public SuperMusician(String name, String instrument, int age) {
        super(name, instrument, age);
    }
    
    public String sing(){
        return "Nothing Else Matters";
    }
    
}
