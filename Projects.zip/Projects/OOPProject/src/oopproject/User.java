/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopproject;

/**
 *
 * @author kaganulu
 */
public class User extends People {
    // Property
    String name;
    String job;
    
    // Constructor 

    public User(String name, String job) {
        this.name = name;
        this.job = job;
        
        System.out.println("User Created");
    }
    
}
