/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javatelafi;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class JavaTelafi {

   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /* 
        while ( koşul ) {
                Tekrarlanacak Kod bloğu
            }
            
            do {
                Tekrarlanacak Kod bloğu
            } while ( koşul );
        
            for ( iteratör başlangıç değeri ; koşul ; iteratör aritmetik operasyonu ) {
                Tekrarlanacak Kod bloğu
          }
          */
         
 /* 
        int sayi1 = 0;
        do {
            System.out.println(sayi1);
            sayi1++;
        } while (sayi1 > 10);
        
        
        
        int sayac = 0;
        if (sayac == 0) {
            sayi1 = 11;
        }
        while (sayi1 > 10) {
            if (sayac == 0) {
                sayi1 = 0;
            }
            sayac++;
            System.out.println(sayi1);
        }
         */
        //for
        /* for (int i = 0; i < 10; i++) {
            System.out.println(i);
        }

        for (int i = 1; i <= 10; i++) {
            for (int j = 1; j <= 10; j++) {
                System.out.println(i + " x " + j + " = " + i * j);
            }
        }

        // 1 ile 100 arasındai ardisik 2li grupların toplamlarını yazınız.
        // 1,2 -3,4 - 5,6 - 7,8 9,10 - 11,12
        //  3    7     11    15  19      23
        int ardisikToplam = 0;
        for (int i = 1; i <= 100; i += 2) {
            ardisikToplam = i + i + 1;
            System.out.println("TOplamlar " + ardisikToplam);
        }

        for (int i = 1; i <= 50; i++) {
            System.out.println(i * 2 + i * 2 - 1);
        }*/
        // 998 ile 7962 arasindaki 193e tam bölünebilen son sayı kactır?
            for (int i = 998; i <= 7962; i++) {
            if (i % 193 == 0) {
                if (i + 193 > 7962) {
                    System.out.println("Birinci yöntem" + i);
                }
            }
        }

        for (int i = 7962; i >= 990; i--) {
            if (i % 193 == 0) {
                System.out.println("İkinci yöntem" + i);
                break;
            }
        }

        // 55 ile 100 arasindaki asal sayiları yazdırın
        // 1- kendisi dahil toplamda 2 sayiya tam bölünebilir

        /*
        int tamBölenSayısı = 0;
        
        for (int i = 55; i <= 100; i++) {
            tamBölenSayısı = 0;
            for (int j = 1; j <= i; j++) {
                if ( i % j == 0 ) {
                    tamBölenSayısı++;
                }
            }
            if ( tamBölenSayısı == 2 ) {
                System.out.println("Asal Sayı" + i);
            }
            
        }
         */
        
     /*   // 2- Kendisine ve 1e tam bölünebilir.
        int tamBölenSayısı = 0;

        for (int i = 55; i <= 100; i++) {
            tamBölenSayısı = 0;
            for (int j = 2; j < i; j++) {
                if (i % j == 0) {
                    tamBölenSayısı++;
                }
            }
            if (tamBölenSayısı == 0) {
                System.out.println("Asal Sayı" + i);
            } else{
                System.out.println("Asal değil" + i);
            }
        }
      */  
     
        // Asal Sayısı Bulma 
        
         Scanner scan = new Scanner(System.in);
         int input;
         boolean asal = true;
         
         do {
            System.out.println("Lütfen 2 den büyük pozitif bir sayı giriniz: ");
            input = scan.nextInt();
            
        } while (input < 2);
        
          for (int i = 2; i < input; i++) {
              if (input % i == 0 ) {
                  asal = false;
                  break;
              }
              
             } 
          
              if (asal) {
                  System.out.println("Girilen sayı :  " + input + " asaldır.");
                  
              } else {
                  System.out.println("Girilen sayı :  " + input + " asal değildir. ");
              }
        
          // Armstrong Sayılar 
          // mesela 153 =( 1*1*1) + (5*5*5) + (3*3*3)
       
      /*    int temp,birler,onlar,yüzler,toplam;
        for (int i = 100; i <= 999; i++) {
            temp =i;
            
            
            birler = temp % 10;
            temp /= 10;
            
            onlar = temp % 10;
            temp /= 10;
            
            yüzler = temp % 10;
            temp /= 10;
            
            toplam = (birler*birler*birler) + (yüzler*yüzler*yüzler) + (onlar*onlar*onlar);
            if (toplam == i) {
                System.out.println(i + " bir Armstrong sayıdır.");
            }
        }
       */  
        // Fibonacci Serisi 0,1,1,2,3,5,8...
        
         Scanner scn = new Scanner(System.in);
         System.out.println("Bir sayı giriniz: ");
         int imput = scn.nextInt();
         
         int s1 = 0;
         int s2 = 1;
         int toplam;
         
          System.out.println(imput + "sayısının Fibonacci serisi ");
         
         for (int i = 1; i <= imput; i++) {
             System.out.print(s1 + " , ");
            
             
             toplam = s1 + s2;
             s1 = s2;
             s2 = toplam;
        }
              
    }

}
