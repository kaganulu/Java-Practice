/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main2;

/**
 *
 * @author kaganulu
 */
public class CustomerManager {
    public void List(){
        System.out.println("Müşteri Listelendi. ");
    }
    public void Add(){
        System.out.println("Eklendi.");
    }
}
