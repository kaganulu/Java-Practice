/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package odev;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Odev {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        System.out.println("Liste uzunluğunu giriniz");
        int listeUzunlugu = sc.nextInt();
        int[] sayilar = randomDiziOlustur(listeUzunlugu);
         diziYazdır(sayilar, "Random Dizi "); 
       
        System.out.println("Dizi oluşturuldu");
       
        int max;                
        int maxIndex = 0;   
        boolean güncellendi = false;  
        for (int i = 0; i < sayilar.length - 1; i++) {
            max = Integer.MIN_VALUE; // max  değeri en küçük ınteger değerine eşittir. Çünkü her sayı benim en küçük sayı değerinden büyük veya eşit olacağıiçin sayıyı günceller.
            güncellendi = false;
            
            for (int j = i + 1; j < sayilar.length; j++) { // i değerinden sonrakilerde i den küçük değer var mı diye bakıyoruz.
                if (sayilar[i] < sayilar[j] && sayilar[j] > max) {    // içindeki değeri max da tutuyoruz. max index te index numarası tutuyoruz.
                    max = sayilar[j];
                    maxIndex = j;  
                    güncellendi = true;
                    
                }
    
                
            }
            if (güncellendi) {
                swap(sayilar, i , maxIndex);
            }
            
        }
        diziYazdır(sayilar, "Sıralı Dizi ");      
            
        }

    private static void diziYazdır(int[] dizi, String metin) {
       System.out.println(metin);
        for (int i = 0; i < dizi.length; i++) {
            System.out.printf("dizi[%d] = %d\n", i, dizi[i]);
        }
    }

    private static void swap(int[] dizi, int pozisyon1, int pozisyon2) {
        if (pozisyon1 >= 0 && pozisyon2 >= 0 && pozisyon1 < dizi.length && pozisyon2 < dizi.length) {
            
            int temp;
                temp = dizi[pozisyon1];
                dizi[pozisyon1] = dizi[pozisyon2];
                dizi[pozisyon2] = temp;
                
        }  else{
            System.out.println("Girdiğiniz değerler dizi uzunluğunun dışındadır.");
        }      
    }
   
       
           
              
    private static int[] randomDiziOlustur(int listeUzunlugu) {
        int[] yeniDizi = new int[listeUzunlugu];
        Random r = new Random(0);
        for (int i = 0; i < listeUzunlugu; i++) {
            yeniDizi[i] = r.nextInt();
        }
        System.out.println("Dizi oluşturuldu");
        return yeniDizi;
    }
  
}
