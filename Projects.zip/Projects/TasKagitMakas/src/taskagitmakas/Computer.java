/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taskagitmakas;

import java.util.Random;

/**
 *
 * @author kaganulu
 */
public class Computer {
    private String computerHandChoice;
    Random rand = new Random();
    
    public void computerHand(){
         int randNum = rand.nextInt(3);
         switch(randNum){
             case 0:
                 this.computerHandChoice = "T";
                 System.out.println("Bilgisayar Taşı Seçti");
                 break;
                 
             case 1:
                 this.computerHandChoice = "K";
                 System.out.println("Bilgisayar Kağıdı Seçti");
                break;
                 
             case 2:
                 this.computerHandChoice = "M";
                  System.out.println("Bilgisayar Makası Seçti");
                break;
                         
         }
                 
    }

    public String getComputerHandChoice() {
        return computerHandChoice;
    }
    
    
   
}
