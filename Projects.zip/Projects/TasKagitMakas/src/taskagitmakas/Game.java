/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taskagitmakas;

import java.util.Scanner;

/**
 *
 * @author kaganulu
 */
public class Game {
    Scanner scan = new Scanner(System.in);
    private String playerName = "";
    private String playerHandChoice;
    Computer com = new Computer();
    
    public Game(){
        
    }
    
    public Game(String playerName){
        this.playerName = playerName;
    }

    public String getPlayerName() {
        return playerName;
    }
    
    
    
    public void playerHand(){
        this.playerHandChoice = scan.nextLine();
        if (playerHandChoice.equalsIgnoreCase("T")) {
            System.out.println("Oyuncu Taş'ı seçti.");
        }else if (playerHandChoice.equalsIgnoreCase("K")) {
            System.out.println("Oyuncu Kağıdı seçti.");

        }else if (playerHandChoice.equalsIgnoreCase("M")) {
             System.out.println("Oyuncu Makası seçti.");
        }else{
            System.out.println("Yanlış Giriş Yapıldı!");
        }
    }
    
    public void startGame(){
        System.out.println("Hoş Geldiniz: " + getPlayerName() + "\nLütfen hangisini seçmek istediğinizi seçiniz:\n Seçimler: [T]Taş, [K]Kağıt, [M]Makas");
        playerHand();
        com.computerHand();
        String computerHandChoice = com.getComputerHandChoice();
        if (playerHandChoice.equalsIgnoreCase("T") && computerHandChoice.equalsIgnoreCase("K")) {
            System.out.println("Bilgisayar Kazandı");
            
        }else if (playerHandChoice.equalsIgnoreCase("T") && computerHandChoice.equalsIgnoreCase("M")) {
             System.out.println("Oyuncu Kazandı");
        }else if (playerHandChoice.equalsIgnoreCase("K") && computerHandChoice.equalsIgnoreCase("T")) {
             System.out.println("Oyuncu Kazandı");
        }else if (playerHandChoice.equalsIgnoreCase("M") && computerHandChoice.equalsIgnoreCase("K")) {
             System.out.println("Oyuncu Kazandı");
        }else if (playerHandChoice.equalsIgnoreCase("M") && computerHandChoice.equalsIgnoreCase("T")) {
             System.out.println("Bilgisayar Kazandı");
        }else if (playerHandChoice.equalsIgnoreCase("K") && computerHandChoice.equalsIgnoreCase("M")) {
             System.out.println("Bilgisayar Kazandı");
        }else
            System.out.println("Berabere Kaldılar");
        }
    }
    

